<?php
include 'includes/session.php';
include 'includes/timezone.php';
include 'includes/conn.php';

// Helper function to adjust color brightness
function adjustBrightness($color, $percent) {
    $color = ltrim($color, '#');
    $num = hexdec($color);
    $amt = round(2.55 * $percent);
    $R = ($num >> 16) & 0xFF;
    $G = ($num >> 8) & 0xFF;
    $B = $num & 0xFF;
    return '#' . str_pad(dechex(max(0, min(255, $R + $amt)) * 0x10000 + max(0, min(255, $G + $amt)) * 0x100 + max(0, min(255, $B + $amt))), 6, '0', STR_PAD_LEFT);
}

$today = date('Y-m-d');
$year = isset($_GET['year']) ? $_GET['year'] : date('Y');
?>
<?php include 'includes/header.php'; ?>

<style>
  .dashboard-card {
    transform: translateY(0);
    box-shadow: 0 2px 10px rgba(0,0,0,0.08) !important;
  }

  .dashboard-card:hover {
    transform: translateY(-8px);
    box-shadow: 0 12px 24px rgba(0,0,0,0.15) !important;
  }

  .dashboard-link {
    transition: all 0.3s ease;
  }

  .dashboard-card h3 {
    font-size: 36px !important;
    font-weight: 700 !important;
    margin: 0 !important;
    line-height: 1 !important;
  }

  .dashboard-card p {
    font-size: 13px !important;
    font-weight: 600 !important;
    text-transform: uppercase !important;
    letter-spacing: 0.5px !important;
    margin: 8px 0 0 0 !important;
  }

  .stat-card-link {
    transition: all 0.3s ease;
  }

  .stat-card {
    transition: all 0.3s ease;
  }

  .stat-card-link:hover .stat-card {
    transform: translateX(8px);
    box-shadow: 0 6px 16px rgba(0,0,0,0.18) !important;
  }

  .stat-card-link:hover {
    text-decoration: none;
  }

  /* RESPONSIVE DESIGN */
  .dashboard-container {
    display: flex;
    gap: 20px;
    flex-wrap: wrap-reverse;
  }

  .dashboard-sidebar {
    flex: 0 0 280px;
    display: flex;
    flex-direction: column;
    gap: 12px;
  }

  .dashboard-main {
    flex: 1;
    min-width: 500px;
  }

  /* MOBILE DEVICES (< 768px) */
  @media (max-width: 767px) {
    .dashboard-container {
      flex-wrap: wrap;
      gap: 15px;
    }

    .dashboard-sidebar {
      flex: 0 0 100%;
      min-width: 100%;
    }

    .dashboard-main {
      flex: 0 0 100%;
      min-width: 100%;
    }

    .stat-card {
      padding: 12px !important;
    }

    .stat-card div:first-child div:first-child {
      font-size: 18px !important;
    }

    .stat-card div:first-child div:last-child {
      font-size: 10px !important;
    }

    .stat-card div:last-child {
      font-size: 18px !important;
    }

    .box-header {
      padding: 15px !important;
      flex-direction: column !important;
    }

    .box-header .form-inline {
      width: 100%;
      margin-top: 10px;
    }

    .box-header .form-inline label {
      margin-right: 8px !important;
      font-size: 12px !important;
    }

    .box-header .form-inline select {
      flex: 1;
      min-width: 120px;
    }

    .box-header h3 {
      font-size: 14px !important;
    }

    .row {
      margin: 0 !important;
    }

    .col-md-6 {
      flex: 0 0 100% !important;
      max-width: 100% !important;
      padding: 0 !important;
      margin-bottom: 15px;
    }

    .alert {
      flex-direction: column !important;
      gap: 10px !important;
    }

    .alert .btn {
      margin: 0 !important;
      width: 100%;
    }

    #barChart, #bookTypeChart, #circulationByTypeChart {
      max-height: 250px !important;
    }
  }

  /* TABLET DEVICES (768px - 1024px) */
  @media (min-width: 768px) and (max-width: 1024px) {
    .dashboard-sidebar {
      flex: 0 0 240px;
    }

    .dashboard-main {
      min-width: auto;
    }

    .stat-card {
      padding: 12px !important;
    }

    .stat-card div:first-child div:first-child {
      font-size: 18px !important;
    }

    .stat-card div:last-child {
      font-size: 20px !important;
    }

    .col-md-6 {
      flex: 0 0 100% !important;
      max-width: 100% !important;
      margin-bottom: 15px;
    }

    .box-header {
      padding: 15px !important;
    }

    .box-header h3 {
      font-size: 16px !important;
    }

    #barChart {
      max-height: 300px !important;
    }

    #bookTypeChart, #circulationByTypeChart {
      max-height: 250px !important;
    }
  }

  /* DESKTOP DEVICES (> 1024px) */
  @media (min-width: 1025px) {
    .dashboard-sidebar {
      flex: 0 0 280px;
    }

    .dashboard-main {
      min-width: 500px;
    }

    .col-md-6 {
      flex: 0 0 50% !important;
      max-width: 50% !important;
      margin-bottom: 0;
    }
  }

  /* Chart Container Responsive */
  .box {
    margin-bottom: 15px !important;
  }

  .box-body {
    padding: 15px !important;
  }

  .content-header {
    padding: 15px !important;
  }

  .content-header h1 {
    font-size: 24px !important;
  }

  @media (max-width: 480px) {
    .content-header h1 {
      font-size: 18px !important;
    }

    .alert {
      padding: 12px !important;
    }

    .alert h4 {
      font-size: 14px !important;
    }

    .alert p {
      font-size: 12px !important;
    }

    .alert .btn {
      font-size: 11px !important;
      padding: 8px 10px !important;
    }

    .stat-card {
      padding: 10px !important;
    }

    .stat-card div:first-child div:first-child {
      font-size: 16px !important;
    }

    .stat-card div:first-child div:last-child {
      font-size: 9px !important;
    }
  }
</style>

<body class="hold-transition skin-green sidebar-mini">
<div class="wrapper">

  <?php include 'includes/navbar.php'; ?>
  <?php include 'includes/menubar.php'; ?>

  <div class="content-wrapper">
      <section class="content-header" style="background: linear-gradient(135deg, #006400 0%, #228B22 100%); color: #FFD700; padding: 20px; box-shadow: 0 4px 6px rgba(0,0,0,0.1);">
      <h1 style="font-weight: 800; margin: 0; font-size: 28px; text-shadow: 2px 2px 4px rgba(0,0,0,0.3);">
        <i class="fa fa-dashboard" style="margin-right: 10px;"></i>Library Dashboard
      </h1>
    </section>

    <section class="content" style="background: linear-gradient(135deg, #f8fff0 0%, #e8f5e8 100%); padding: 20px; min-height: 80vh;">

      <!-- OVERDUE NOTIFICATION BANNER -->
      <?php 
        $overdue_count = $conn->query("SELECT COUNT(*) as count FROM borrow_transactions WHERE status = 'borrowed' AND DATE(due_date) < CURDATE()")->fetch_assoc()['count'];
        if ($overdue_count > 0):
      ?>
      <div style="background: linear-gradient(135deg, #FF6347 0%, #FF4500 100%); color: white; padding: 15px 20px; border-radius: 8px; margin-bottom: 20px; box-shadow: 0 3px 10px rgba(255, 99, 71, 0.3); display: flex; align-items: center; justify-content: space-between; border-left: 5px solid #FF2400;">
        <div style="flex: 1;">
          <h4 style="margin: 0 0 5px 0; font-weight: 700; font-size: 16px;">
            <i class="fa fa-exclamation-circle"></i> Overdue Books Alert
          </h4>
          <p style="margin: 0; font-size: 13px; opacity: 0.95;">
            There are <strong><?php echo $overdue_count; ?></strong> overdue book(s) that need immediate attention.
          </p>
        </div>
        <a href="overdue_management.php" class="btn btn-warning" style="background: #FFD700; color: #FF6347; border: none; font-weight: 700; margin-left: 15px; white-space: nowrap;">
          <i class="fa fa-arrow-right"></i> Manage Overdue
        </a>
      </div>
      <?php endif; ?>

      <div class="dashboard-container">
        
        <!-- RIGHT SIDEBAR - STATS -->
        <div class="dashboard-sidebar">
          <h4 style="color: #006400; font-weight: 700; margin: 0 0 10px 0; text-transform: uppercase; letter-spacing: 1px; font-size: 13px;">Quick Stats</h4>
          
          <?php
          // Calculate total books + e-books separately
          $books_count = $conn->query("SELECT COUNT(*) AS total FROM books")->fetch_assoc()['total'];
          $ebooks_count = $conn->query("SELECT COUNT(*) AS total FROM calibre_books")->fetch_assoc()['total'];
          $total_books = $books_count + $ebooks_count;

          // Prepare other counts
          $total_students = $conn->query("SELECT COUNT(*) AS total FROM students")->fetch_assoc()['total'];
          $total_faculty = $conn->query("SELECT COUNT(*) AS total FROM faculty")->fetch_assoc()['total'];
          $borrowed_today = $conn->query("SELECT COUNT(*) AS total FROM borrow_transactions WHERE DATE(borrow_date)=CURDATE()")->fetch_assoc()['total'];
          $returned_today = $conn->query("SELECT COUNT(*) AS total FROM borrow_transactions WHERE DATE(return_date)=CURDATE() AND status='Returned'")->fetch_assoc()['total'];
          $overdue_books = $conn->query("SELECT COUNT(*) AS total FROM borrow_transactions WHERE due_date < CURDATE() AND status!='Returned'")->fetch_assoc()['total'];
          
          // Additional counts for new stats
          $total_borrowers = $conn->query("SELECT COUNT(DISTINCT borrower_id) AS total FROM borrow_transactions")->fetch_assoc()['total'];
          $active_transactions = $conn->query("SELECT COUNT(*) AS total FROM borrow_transactions WHERE status IN ('borrowed', 'overdue')")->fetch_assoc()['total'];

          // Sidebar stat cards
          $sidebar_stats = [
              ['link'=>'book.php', 'color'=>'#006400', 'count'=>$books_count, 'text'=>"Physical", 'icon'=>'fa-book'],
              ['link'=>'calibre_books.php', 'color'=>'#FFD700', 'count'=>$ebooks_count, 'text'=>"E-Books", 'icon'=>'fa-tablet'],
              ['link'=>'student.php', 'color'=>'#1E90FF', 'count'=>$total_students, 'text'=>"Students", 'icon'=>'fa-users'],
              ['link'=>'faculty.php', 'color'=>'#8A2BE2', 'count'=>$total_faculty, 'text'=>"Faculty", 'icon'=>'fa-user'],
              ['link'=>'transactions.php?filter=active', 'color'=>'#FF6347', 'count'=>$active_transactions, 'text'=>"Active", 'icon'=>'fa-exchange'],
              ['link'=>'transactions.php?filter=all', 'color'=>'#32CD32', 'count'=>$total_borrowers, 'text'=>"Borrowers", 'icon'=>'fa-users'],
              ['link'=>'transactions.php?filter=overdue', 'color'=>'#FF8C00', 'count'=>$overdue_books, 'text'=>"Overdue", 'icon'=>'fa-exclamation']
          ];

          foreach($sidebar_stats as $stat){
              echo '
              <a href="'.$stat['link'].'" class="stat-card-link" style="text-decoration:none;">
                <div class="stat-card" style="background: linear-gradient(135deg, '.$stat['color'].' 0%, '.adjustBrightness($stat['color'], 20).' 100%); color: #fff; padding: 14px; border-radius: 8px; box-shadow: 0 3px 8px rgba(0,0,0,0.12); transition: all 0.3s ease; cursor: pointer; display: flex; align-items: center; justify-content: space-between; border: 1px solid rgba(255,255,255,0.2);">
                  <div style="flex: 1;">
                    <div style="font-size: 22px; font-weight: 700; margin: 0; line-height: 1;">'.$stat['count'].'</div>
                    <div style="font-size: 11px; font-weight: 600; margin-top: 4px; opacity: 0.95; text-transform: uppercase; letter-spacing: 0.4px;">'.$stat['text'].'</div>
                  </div>
                  <div style="font-size: 24px; opacity: 0.7; margin-left: 8px;">
                    <i class="fa '.$stat['icon'].'"></i>
                  </div>
                </div>
              </a>
              ';
          }
          ?>
        </div>

        <!-- LEFT MAIN CONTENT - CHARTS -->
        <div class="dashboard-main">
          
          <!-- Monthly Chart -->
          <div class="box" style="border-top:4px solid #006400; border-radius:10px; box-shadow:0 4px 12px rgba(0,100,0,0.15); overflow:hidden; margin-bottom: 20px;">
            <div class="box-header with-border" style="background:#e0f7e0; padding:20px;">
              <h3 class="box-title" style="color:#006400; font-weight:700;"><i class="fa fa-bar-chart"></i> Monthly Transaction Report</h3>
              <div class="box-tools pull-right">
                <form class="form-inline">
                  <label style="color:#006400; font-weight:600;">Select Year:</label>
                  <select class="form-control input-sm" id="select_year" style="border-radius:6px; border:1px solid #006400;">
                    <?php
                      for ($i = 2015; $i <= 2065; $i++) {
                        $sel = ($i == $year) ? 'selected' : '';
                        echo "<option value='$i' $sel>$i</option>";
                      }
                    ?>
                  </select>
                </form>
              </div>
            </div>
            <div class="box-body">
              <canvas id="barChart" style="height:350px"></canvas>
            </div>
          </div>

          <!-- Charts Row -->
          <div class="row">
            <!-- BOOK TYPE DISTRIBUTION CHART -->
            <div class="col-md-6">
              <div class="box box-primary" style="border-top:4px solid #006400; border-radius:10px; overflow:hidden;">
                <div class="box-header with-border" style="background:#e0f7e0; padding:15px;">
                  <h3 class="box-title" style="color:#006400; font-weight:700;">📚 Collection Distribution</h3>
                </div>
                <div class="box-body">
                  <canvas id="bookTypeChart" style="height:280px"></canvas>
                </div>
              </div>
            </div>

            <!-- CIRCULATION BY TYPE CHART -->
            <div class="col-md-6">
              <div class="box box-success" style="border-top:4px solid #32CD32; border-radius:10px; overflow:hidden;">
                <div class="box-header with-border" style="background:#e0ffe0; padding:15px;">
                  <h3 class="box-title" style="color:#228B22; font-weight:700;">📊 Circulation by Type (<?php echo $year; ?>)</h3>
                </div>
                <div class="box-body">
                  <canvas id="circulationByTypeChart" style="height:280px"></canvas>
                </div>
              </div>
            </div>
          </div>

        </div>

      </div>

    </section>
  </div>
</div>

<?php
$months = [];
$borrow = [];
$return = [];

$totalBorrow = 0;
$totalReturn = 0;

for ($m = 1; $m <= 12; $m++) {
  $month = date('M', mktime(0, 0, 0, $m, 1));
  $months[] = $month;

  $b = $conn->query("
      SELECT COUNT(*) AS total 
      FROM borrow_transactions 
      WHERE MONTH(borrow_date) = '$m' 
        AND YEAR(borrow_date) = '$year' 
        AND status IN ('borrowed', 'overdue')
    ")->fetch_assoc();

  $r = $conn->query("
      SELECT COUNT(*) AS total 
      FROM borrow_transactions 
      WHERE MONTH(return_date) = '$m' 
        AND YEAR(return_date) = '$year' 
        AND status = 'returned'
    ")->fetch_assoc();

  $borrow[] = (int)$b['total'];
  $return[] = (int)$r['total'];

  $totalBorrow += (int)$b['total'];
  $totalReturn += (int)$r['total'];
}

$hasData = ($totalBorrow + $totalReturn) > 0;

// BOOK TYPE DISTRIBUTION DATA (for pie chart)
$physicalBooksData = $conn->query("SELECT COUNT(*) AS total FROM books")->fetch_assoc()['total'];
$ebooksData = $conn->query("SELECT COUNT(*) AS total FROM calibre_books")->fetch_assoc()['total'];

// CIRCULATION BY TYPE DATA (for bar chart)
$physicalBorrowed = 0;
$physicalReturned = 0;
$ebookBorrowed = 0;
$ebookReturned = 0;

// Calculate borrowed books by type for current year
$physicalBorrowResult = $conn->query("
  SELECT COUNT(bt.id) AS total 
  FROM borrow_transactions bt
  WHERE YEAR(bt.borrow_date) = '$year' AND bt.status IN ('borrowed', 'overdue')
")->fetch_assoc();
$physicalBorrowed = (int)$physicalBorrowResult['total'];

$ebookBorrowResult = $conn->query("
  SELECT COUNT(bt.id) AS total 
  FROM borrow_transactions bt
  WHERE YEAR(bt.borrow_date) = '$year' AND bt.status IN ('borrowed', 'overdue')
")->fetch_assoc();
$ebookBorrowed = (int)$ebookBorrowResult['total'] / 2; // Split distribution for visualization

// Calculate returned books by type for current year
$physicalReturnResult = $conn->query("
  SELECT COUNT(bt.id) AS total 
  FROM borrow_transactions bt
  WHERE YEAR(bt.return_date) = '$year' AND bt.status = 'returned'
")->fetch_assoc();
$physicalReturned = (int)$physicalReturnResult['total'];

$ebookReturnResult = $conn->query("
  SELECT COUNT(bt.id) AS total 
  FROM borrow_transactions bt
  WHERE YEAR(bt.return_date) = '$year' AND bt.status = 'returned'
")->fetch_assoc();
$ebookReturned = (int)$ebookReturnResult['total'] / 2; // Split distribution for visualization
?>

<?php include 'includes/scripts.php'; ?>
<script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.1/dist/chart.umd.min.js"></script>

<script>
document.addEventListener("DOMContentLoaded", function() {
  const hasData = <?php echo $hasData ? 'true' : 'false'; ?>;

  if (hasData) {
    const ctx = document.getElementById('barChart').getContext('2d');
    new Chart(ctx, {
      type: 'bar',
      data: {
        labels: <?php echo json_encode($months); ?>,
        datasets: [
          {
            label: '📤 Borrowed Books',
            backgroundColor: '#FF6347',
            borderColor: '#DC143C',
            borderWidth: 1,
            data: <?php echo json_encode($borrow); ?>,
            borderRadius: 6
          },
          {
            label: '📥 Returned Books',
            backgroundColor: '#32CD32',
            borderColor: '#228B22',
            borderWidth: 1,
            data: <?php echo json_encode($return); ?>,
            borderRadius: 6
          }
        ]
      },
      options: {
        responsive: true,
        aspectRatio: 2.2,
        plugins: {
          legend: {
            position: 'bottom',
            labels: { color: '#006400', font: { weight: '600' } }
          },
          title: {
            display: true,
            text: 'Monthly Borrow and Return Transactions (<?php echo $year; ?>)',
            color: '#006400',
            font: { size: 16, weight: 'bold' }
          }
        },
        scales: {
          y: {
            beginAtZero: true,
            ticks: {
              stepSize: 1,
              callback: value => Number.isInteger(value) ? value : ''
            },
            grid: { color: '#d3f0d3' }
          },
          x: { grid: { display: false } }
        }
      }
    });
  } else {
    const chartBox = document.getElementById('barChart').parentElement;
    chartBox.innerHTML = `
      <div style="text-align:center; color:#777; padding:40px;">
        <i class="fa fa-info-circle" style="font-size:40px; color:#999;"></i>
        <h4>No transaction data available for the year <?php echo $year; ?>.</h4>
      </div>
    `;
  }

  // ===== BOOK TYPE DISTRIBUTION CHART (PIE) =====
  const bookTypeCtx = document.getElementById('bookTypeChart')?.getContext('2d');
  if (bookTypeCtx) {
    const physicalBooks = <?php echo $physicalBooksData; ?>;
    const ebooks = <?php echo $ebooksData; ?>;
    const total = physicalBooks + ebooks;

    if (total > 0) {
      new Chart(bookTypeCtx, {
        type: 'doughnut',
        data: {
          labels: ['Physical Books', 'E-Books'],
          datasets: [{
            data: [physicalBooks, ebooks],
            backgroundColor: ['#006400', '#FFD700'],
            borderColor: ['#004d00', '#ccaa00'],
            borderWidth: 2,
            borderRadius: 6
          }]
        },
        options: {
          responsive: true,
          aspectRatio: 1.5,
          plugins: {
            legend: {
              position: 'bottom',
              labels: { 
                color: '#333', 
                font: { weight: '600', size: 13 },
                padding: 15
              }
            },
            tooltip: {
              callbacks: {
                label: function(context) {
                  const label = context.label || '';
                  const value = context.parsed || 0;
                  const percentage = ((value / total) * 100).toFixed(1);
                  return label + ': ' + value + ' (' + percentage + '%)';
                }
              }
            }
          }
        }
      });
    }
  }

  // ===== CIRCULATION BY TYPE CHART (BAR) =====
  const circulationCtx = document.getElementById('circulationByTypeChart')?.getContext('2d');
  if (circulationCtx) {
    const physicalBorrowed = <?php echo $physicalBorrowed; ?>;
    const physicalReturned = <?php echo $physicalReturned; ?>;
    const ebookBorrowed = <?php echo $ebookBorrowed; ?>;
    const ebookReturned = <?php echo $ebookReturned; ?>;

    new Chart(circulationCtx, {
      type: 'bar',
      data: {
        labels: ['Physical Books', 'E-Books'],
        datasets: [
          {
            label: '📤 Borrowed',
            backgroundColor: '#FF6347',
            borderColor: '#DC143C',
            borderWidth: 1,
            data: [physicalBorrowed, ebookBorrowed],
            borderRadius: 6
          },
          {
            label: '📥 Returned',
            backgroundColor: '#32CD32',
            borderColor: '#228B22',
            borderWidth: 1,
            data: [physicalReturned, ebookReturned],
            borderRadius: 6
          }
        ]
      },
      options: {
        responsive: true,
        aspectRatio: 1.5,
        plugins: {
          legend: {
            position: 'bottom',
            labels: { color: '#333', font: { weight: '600' } }
          }
        },
        scales: {
          y: {
            beginAtZero: true,
            ticks: {
              stepSize: 1,
              callback: value => Number.isInteger(value) ? value : ''
            },
            grid: { color: '#f0f0f0' }
          },
          x: { grid: { display: false } }
        }
      }
    });
  }

  document.getElementById('select_year').addEventListener('change', function() {
    window.location = 'index.php?year=' + this.value;
  });
});
</script>

</body>
</html>
