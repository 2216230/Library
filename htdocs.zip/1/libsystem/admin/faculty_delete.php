<?php
include 'includes/session.php';
include 'includes/conn.php';

if(isset($_POST['id'])){
    $id = intval($_POST['id']);

    // Check if faculty has any transactions
    $checkTrans = $conn->prepare("SELECT COUNT(*) as trans_count FROM borrow_transactions WHERE borrower_id = ? AND borrower_type = 'faculty'");
    $checkTrans->bind_param("i", $id);
    $checkTrans->execute();
    $transResult = $checkTrans->get_result();
    $transData = $transResult->fetch_assoc();
    $checkTrans->close();

    if ($transData['trans_count'] > 0) {
        $_SESSION['error'] = 'Cannot delete faculty: This faculty member has ' . $transData['trans_count'] . ' transaction(s) on record. Faculty with transactions cannot be deleted.';
    } else {
        $stmt = $conn->prepare("UPDATE faculty SET archived = 1 WHERE id = ?");
        $stmt->bind_param("i", $id);

        if($stmt->execute()){
            $_SESSION['success'] = "Faculty archived successfully.";
        } else {
            $_SESSION['error'] = "Error archiving faculty.";
        }
    }
} else {
    $_SESSION['error'] = "No faculty selected.";
}

header("Location: faculty.php");
exit;
?>
