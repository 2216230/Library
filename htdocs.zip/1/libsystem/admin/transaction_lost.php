<?php
include 'includes/session.php';
include 'includes/conn.php';

$id = $_POST['id'] ?? null;

if (!$id) {
    echo json_encode(['status' => 'error', 'message' => 'Transaction ID is required']);
    exit;
}

// Get the copy_id first
$get_stmt = $conn->prepare("SELECT copy_id FROM borrow_transactions WHERE id = ? LIMIT 1");
$get_stmt->bind_param('i', $id);
$get_stmt->execute();
$get_result = $get_stmt->get_result();
$transaction = $get_result->fetch_assoc();
$get_stmt->close();

// Update transaction status to 'lost'
$update_sql = "UPDATE borrow_transactions SET status = 'lost' WHERE id = ?";
$stmt = $conn->prepare($update_sql);
$stmt->bind_param('i', $id);

if ($stmt->execute()) {
    // Also update book_copies availability to 'lost' if copy_id exists
    if (!empty($transaction['copy_id'])) {
        $copy_id_int = intval($transaction['copy_id']);
        $update_copy = $conn->prepare("UPDATE book_copies SET availability = 'lost' WHERE id = ?");
        if ($update_copy) {
            $update_copy->bind_param('i', $copy_id_int);
            $update_copy->execute();
            $update_copy->close();
        }
    }
    
    echo json_encode(['status' => 'success', 'message' => 'Book marked as lost']);
} else {
    echo json_encode(['status' => 'error', 'message' => 'Update failed: ' . $conn->error]);
}
$stmt->close();
?>
