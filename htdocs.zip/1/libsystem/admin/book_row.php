<?php
include 'includes/session.php';
include 'includes/conn.php';

if (isset($_POST['id'])) {
    $id = intval($_POST['id']);

    // 1. Fetch the selected book
    $sql = "SELECT * FROM books WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $book = $stmt->get_result()->fetch_assoc();
    $stmt->close();

    if (!$book) {
        echo json_encode(['error' => 'Invalid book ID']);
        exit();
    }

    // 2. Fetch single category assigned to this book
    $selectedCat = '';
    $cat_sql = "
        SELECT c.id, c.name 
        FROM category c
        INNER JOIN book_category_map bcm ON c.id = bcm.category_id
        WHERE bcm.book_id = ? 
        LIMIT 1
    ";
    $stmt = $conn->prepare($cat_sql);
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $res = $stmt->get_result();
    if ($row = $res->fetch_assoc()) {
        $selectedCat = (string)$row['id'];
    }
    $stmt->close();

    // 3. Fetch course subjects assigned to this book (optional multiple)
    $selectedSubjects = [];
    $sub_sql = "SELECT subject_id FROM book_subject_map WHERE book_id = ?";
    $stmt = $conn->prepare($sub_sql);
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $result = $stmt->get_result();
    while ($row = $result->fetch_assoc()) {
        $selectedSubjects[] = (string)$row['subject_id'];
    }
    $stmt->close();

    // 4. Return JSON for edit modal
    echo json_encode([
        'id' => $book['id'],
        'isbn' => $book['isbn'],
        'call_no' => $book['call_no'],
        'title' => $book['title'],
        'author' => $book['author'],
        'publisher' => $book['publisher'],
        'publish_date' => $book['publish_date'],
        'subject' => $book['subject'] ?? '',
        'category' => $selectedCat,          // single category
        'subjects' => $selectedSubjects,     // multiple course subjects
        'section' => $book['section'] ?? '',
        'num_copies' => $book['num_copies'] ?? 1
    ]);
}
?>
