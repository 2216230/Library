<?php
include 'includes/session.php';
include 'includes/conn.php';

if(!isset($_POST['copy_id'])){
    echo json_encode(['error'=>'Copy ID required']);
    exit();
}

$copy_id = intval($_POST['copy_id']);

// Only delete if available
$stmt = $conn->prepare("DELETE FROM book_copies WHERE id=? AND availability='Available'");
$stmt->bind_param("i",$copy_id);
$stmt->execute();
if($stmt->affected_rows > 0){
    echo json_encode(['success'=>true]);
} else {
    echo json_encode(['error'=>'Cannot delete borrowed copy']);
}
$stmt->close();
