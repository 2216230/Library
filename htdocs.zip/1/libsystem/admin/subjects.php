<?php
include 'includes/session.php';
include 'includes/conn.php';
include 'includes/header.php';
include 'alert_modal.php';
?>
<body class="hold-transition skin-green sidebar-mini">
<div class="wrapper">
  <?php include 'includes/navbar.php'; ?>
  <?php include 'includes/menubar.php'; ?>

  <div class="content-wrapper">
    <!-- Enhanced Header -->
    <section class="content-header" style="background: linear-gradient(135deg, #006400 0%, #228B22 100%); color: #FFD700; padding: 20px; box-shadow: 0 4px 6px rgba(0,0,0,0.1);">
      <h1 style="font-weight: 800; margin: 0; font-size: 28px; text-shadow: 2px 2px 4px rgba(0,0,0,0.3);">
        <i class="fa fa-bookmark" style="margin-right: 10px;"></i>Subject Management
      </h1>
    </section>

    <!-- Main Content -->
    <section class="content" style="background: linear-gradient(135deg, #f8fff0 0%, #e8f5e8 100%); padding: 20px; border-radius: 0 0 10px 10px; min-height: 80vh;">

      <?php
        // Enhanced Error/Success Messages
        if(isset($_SESSION['error'])){
          echo "
          <div class='alert alert-danger alert-dismissible' style='background: linear-gradient(135deg, #ff6b6b 0%, #ee5a52 100%); color: white; border: none; border-radius: 8px; box-shadow: 0 2px 4px rgba(0,0,0,0.1); margin-bottom: 20px;'>
            <button type='button' class='close' data-dismiss='alert' aria-hidden='true' style='color: white; opacity: 0.8;'>&times;</button>
            <h4><i class='icon fa fa-warning'></i> Alert!</h4>".$_SESSION['error']."
          </div>";
          unset($_SESSION['error']);
        }
        if(isset($_SESSION['success'])){
          echo "
          <div class='alert alert-success alert-dismissible' style='background: linear-gradient(135deg, #32CD32 0%, #28a428 100%); color: #003300; border: none; border-radius: 8px; box-shadow: 0 2px 4px rgba(0,0,0,0.1); margin-bottom: 20px;'>
            <button type='button' class='close' data-dismiss='alert' aria-hidden='true' style='color: #003300; opacity: 0.8;'>&times;</button>
            <h4><i class='icon fa fa-check'></i> Success!</h4>".$_SESSION['success']."
          </div>";
          unset($_SESSION['success']);
        }
      ?>

      <div class="row">
        <div class="col-xs-12">
          <div class="box" style="border: none; border-radius: 10px; box-shadow: 0 4px 12px rgba(0,100,0,0.15); overflow: hidden;">

            <!-- Enhanced Box Header -->
            <div class="box-header with-border" style="background: linear-gradient(135deg, #f0fff0 0%, #e0f7e0 100%); padding: 20px; border-bottom: 2px solid #006400;">
              <div class="row">
                <div class="col-md-6">
                  <h3 style="font-weight: 700; color: #006400; margin: 0; font-size: 22px;">
                    <i class="fa fa-book" style="margin-right: 10px;"></i>Course Book Subjects
                  </h3>
                  <small style="color: #006400; font-weight: 500;">Assign books to course subjects for better organization and management</small>
                </div>
                <div class="col-md-6 text-right">
                  <button data-toggle="modal" data-target="#addSubjectModal" 
                    class="btn btn-success btn-flat" 
                    style="background: linear-gradient(135deg, #32CD32 0%, #228B22 100%); border: none; border-radius: 6px; font-weight: 600; padding: 8px 20px; box-shadow: 0 2px 4px rgba(0,100,0,0.2);">
                    <i class="fa fa-plus-circle"></i> Add New Subject
                  </button>
                </div>
              </div>
            </div>

            <!-- Box Body with Table -->
            <div class="box-body">
              <!-- Show/Search Section -->
              <div class="row" style="margin-bottom: 20px; align-items: center;">
                <div class="col-sm-6">
                  <div style="display: flex; align-items: center; gap: 10px;">
                    <label style="margin: 0; font-weight: 600; color: #006400;">Show</label>
                    <select id="pageLength" class="form-control" style="width: 80px; border-radius: 6px; border: 1px solid #006400;">
                      <option value="10">10</option>
                      <option value="25">25</option>
                      <option value="50">50</option>
                      <option value="100">100</option>
                    </select>
                    <label style="margin: 0; font-weight: 600; color: #006400;">subjects per page</label>
                  </div>
                </div>
                <div class="col-sm-6 text-right">
                  <div style="display: flex; align-items: center; gap: 10px; justify-content: flex-end;">
                    <i class="fa fa-search" style="color: #006400; font-size: 16px;"></i>
                    <input type="text" id="subjectSearch" class="form-control" placeholder="Search subjects..." style="width: 250px; border-radius: 6px; border: 1px solid #006400;">
                  </div>
                </div>
              </div>

              <!-- Subjects Table -->
              <div class="table-responsive">
                <table class="table table-bordered table-hover" id="subjectsTable">
                  <thead style="background: linear-gradient(135deg, #006400 0%, #228B22 100%); color: white; font-weight: 700;">
                    <tr>
                      <th style="color: white; padding: 13px 8px; font-weight: 700; font-size: 13px; white-space: nowrap; width: 50px;">#</th>
                      <th style="color: white; padding: 13px 8px; font-weight: 700; cursor: pointer; font-size: 13px; white-space: nowrap;" onclick="sortTable('name')">
                        <i class="fa fa-book" style="margin-right: 6px;"></i>Subject Name <?php if(isset($_GET['sort']) && $_GET['sort'] === 'name') echo (isset($_GET['order']) && $_GET['order'] === 'ASC') ? '▲' : '▼'; ?>
                      </th>
                      <th style="color: white; padding: 13px 8px; font-weight: 700; cursor: pointer; font-size: 13px; white-space: nowrap; text-align: center;" onclick="sortTable('books_count')">
                        <i class="fa fa-book-open" style="margin-right: 6px;"></i>Books Assigned <?php if(isset($_GET['sort']) && $_GET['sort'] === 'books_count') echo (isset($_GET['order']) && $_GET['order'] === 'ASC') ? '▲' : '▼'; ?>
                      </th>
                      <th style="color: white; padding: 13px 8px; font-weight: 700; font-size: 13px; white-space: nowrap;">Action</th>
                    </tr>
                  </thead>
                  <tbody id="subjectsTableBody">
                    <?php
                    // Get sort parameters
                    $sort_by = isset($_GET['sort']) ? $_GET['sort'] : 'name';
                    $sort_order = isset($_GET['order']) ? $_GET['order'] : 'ASC';

                    // Validate sort column to prevent SQL injection
                    $allowed_sorts = ['name', 'books_count'];
                    if (!in_array($sort_by, $allowed_sorts)) {
                        $sort_by = 'name';
                    }

                    // Build query with sorting
                    if ($sort_by === 'books_count') {
                        $subject_query = $conn->query("
                            SELECT s.id, s.name, COUNT(bsm.id) as book_count
                            FROM subject s
                            LEFT JOIN book_subject_map bsm ON bsm.subject_id = s.id
                            GROUP BY s.id, s.name
                            ORDER BY book_count $sort_order, s.name ASC
                        ");
                    } else {
                        $subject_query = $conn->query("
                            SELECT s.id, s.name, COUNT(bsm.id) as book_count
                            FROM subject s
                            LEFT JOIN book_subject_map bsm ON bsm.subject_id = s.id
                            GROUP BY s.id, s.name
                            ORDER BY s.name $sort_order
                        ");
                    }

                    $count = 1;
                    while($subject = $subject_query->fetch_assoc()){
                        $book_count = $subject['book_count'];

                        echo "<tr style='transition: all 0.2s;'>
                          <td style='padding: 10px 6px; font-size: 14px; width: 50px; text-align: center;'><strong>".$count."</strong></td>
                          <td style='padding: 10px 6px; font-size: 14px;'>
                            <i class='fa fa-folder-open' style='margin-right: 8px; color: #006400;'></i>
                            <strong style='color: #006400;'>".htmlspecialchars($subject['name'])."</strong>
                          </td>
                          <td style='padding: 10px 6px; font-size: 14px; text-align: center;'>
                            <span style='background: linear-gradient(135deg, #32CD32 0%, #228B22 100%); color: white; padding: 3px 10px; border-radius: 12px; font-weight: 600; font-size: 12px;'>".$book_count."</span>
                          </td>
                          <td style='padding: 10px 6px; font-size: 14px;'>
                            <div class='btn-group btn-group-sm' role='group'>
                              <button class='btn btn-info' onclick='editSubject({$subject['id']}, \"".htmlspecialchars($subject['name'])."\")' title='Edit Subject' style='font-size: 12px; padding: 5px 7px;'>
                                <i class='fa fa-edit'></i>
                              </button>
                              <button class='btn btn-warning' onclick='removeSubject({$subject['id']}, \"".htmlspecialchars($subject['name'])."\")' title='Delete Subject' style='font-size: 12px; padding: 5px 7px;'>
                                <i class='fa fa-trash'></i>
                              </button>
                              <button class='btn btn-success manageBooks' data-id='{$subject['id']}' data-name='".htmlspecialchars($subject['name'])."' title='Assign Books' style='font-size: 12px; padding: 5px 7px;'>
                                <i class='fa fa-plus-square'></i>
                              </button>
                            </div>
                          </td>
                        </tr>";
                        $count++;
                    }
                    ?>
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  </div>
</div>

<?php include 'includes/scripts.php'; ?>

<!-- Add Subject Modal -->
<div class="modal fade" id="addSubjectModal" tabindex="-1">
  <div class="modal-dialog">
    <div class="modal-content" style="border: 2px solid #006400; border-radius: 10px; overflow: hidden; box-shadow: 0 4px 12px rgba(0,100,0,0.3);">
      <form method="POST" action="subject_add.php" id="addSubjectForm">
        <div class="modal-header" style="background: linear-gradient(135deg, #006400 0%, #004d00 100%); color: #FFD700; padding: 20px;">
          <h4 class="modal-title" style="font-weight: 700; margin: 0;">
            <i class="fa fa-plus-circle" style="margin-right: 10px;"></i>Add New Subject
          </h4>
          <button type="button" class="close" data-dismiss="modal" style="color: #FFD700; opacity: 0.8;">&times;</button>
        </div>
        <div class="modal-body" style="padding: 25px; background: linear-gradient(135deg, #f8fff8 0%, #ffffff 100%);">
          <div id="addSubjectError" class="alert alert-danger" style="display: none; border-radius: 6px; margin-bottom: 15px;"></div>
          <div class="form-group">
            <label style="font-weight: 600; color: #006400;">📚 Subject Name</label>
            <input type="text" name="subject_name" id="newSubjectName" class="form-control" placeholder="Enter subject name..." required style="border-radius: 6px; border: 1px solid #006400; padding: 10px;">
            <small id="duplicateWarning" style="color: #ff6b6b; font-weight: 600; display: none; margin-top: 5px;">
              <i class="fa fa-exclamation-circle"></i> This subject already exists!
            </small>
          </div>
        </div>
        <div class="modal-footer" style="background: linear-gradient(135deg, #f0fff0 0%, #e0f7e0 100%); padding: 20px;">
          <button type="submit" name="add_subject" id="submitAddSubject" class="btn btn-success btn-flat" style="background: linear-gradient(135deg, #32CD32 0%, #228B22 100%); color: white; border: none; border-radius: 6px; font-weight: 600; padding: 8px 20px;">
            <i class="fa fa-save"></i> Add Subject
          </button>
          <button type="button" class="btn btn-default btn-flat" data-dismiss="modal" style="background: linear-gradient(135deg, #006400 0%, #004d00 100%); color: #FFD700; border: none; border-radius: 6px; font-weight: 600; padding: 8px 20px;">
            <i class="fa fa-close"></i> Close
          </button>
        </div>
      </form>
    </div>
  </div>
</div>

<!-- Edit Subject Modal -->
<div class="modal fade" id="editSubjectModal" tabindex="-1">
  <div class="modal-dialog">
    <div class="modal-content" style="border: 2px solid #006400; border-radius: 10px; overflow: hidden; box-shadow: 0 4px 12px rgba(0,100,0,0.3);">
      <form method="POST" action="subject_edit.php">
        <div class="modal-header" style="background: linear-gradient(135deg, #006400 0%, #004d00 100%); color: #FFD700; padding: 20px;">
          <h4 class="modal-title" style="font-weight: 700; margin: 0;">
            <i class="fa fa-edit" style="margin-right: 10px;"></i>Edit Subject
          </h4>
          <button type="button" class="close" data-dismiss="modal" style="color: #FFD700; opacity: 0.8;">&times;</button>
        </div>
        <div class="modal-body" style="padding: 25px; background: linear-gradient(135deg, #f8fff8 0%, #ffffff 100%);">
          <div class="form-group">
            <label style="font-weight: 600; color: #006400;">📚 Subject Name</label>
            <input type="text" name="subject_name" id="editSubjectName" class="form-control" required style="border-radius: 6px; border: 1px solid #006400; padding: 10px;">
            <input type="hidden" name="subject_id" id="edit_subject_id">
          </div>
        </div>
        <div class="modal-footer" style="background: linear-gradient(135deg, #f0fff0 0%, #e0f7e0 100%); padding: 20px;">
          <button type="submit" name="edit_subject" class="btn btn-primary btn-flat" style="background: linear-gradient(135deg, #FFD700 0%, #FFA500 100%); color: #006400; border: none; border-radius: 6px; font-weight: 600; padding: 8px 20px;">
            <i class="fa fa-save"></i> Save Changes
          </button>
          <button type="button" class="btn btn-default btn-flat" data-dismiss="modal" style="background: linear-gradient(135deg, #006400 0%, #004d00 100%); color: #FFD700; border: none; border-radius: 6px; font-weight: 600; padding: 8px 20px;">
            <i class="fa fa-close"></i> Close
          </button>
        </div>
      </form>
    </div>
  </div>
</div>

<!-- Confirm Remove Subject Modal -->
<div class="modal fade" id="confirmRemoveSubjectModal" tabindex="-1">
  <div class="modal-dialog">
    <div class="modal-content" style="border: 2px solid #8B0000; border-radius: 10px; overflow: hidden; box-shadow: 0 4px 12px rgba(139,0,0,0.3);">
      <form method="POST" action="subject_remove.php">
        <div class="modal-header" style="background: linear-gradient(135deg, #8B0000 0%, #A52A2A 100%); color: #FFD700; padding: 20px;">
          <h4 class="modal-title" style="font-weight: 700; margin: 0;">
            <i class="fa fa-exclamation-triangle" style="margin-right: 10px;"></i>Confirm Remove Subject
          </h4>
          <button type="button" class="close" data-dismiss="modal" style="color: #FFD700; opacity: 0.8;">&times;</button>
        </div>
        <div class="modal-body" style="padding: 25px; background: linear-gradient(135deg, #fff8f8 0%, #ffffff 100%);">
          <p id="removeSubjectMessage" style="font-weight: 500; color: #8B0000;">Are you sure you want to remove this subject?</p>
          <input type="hidden" name="subject_id" id="remove_subject_id">
        </div>
        <div class="modal-footer" style="background: linear-gradient(135deg, #fff0f0 0%, #ffe8e8 100%); padding: 20px;">
          <button type="submit" name="confirm_remove_subject" class="btn btn-danger btn-flat" style="background: linear-gradient(135deg, #ff6b6b 0%, #ee5a52 100%); color: white; border: none; border-radius: 6px; font-weight: 600; padding: 8px 20px;">
            <i class="fa fa-trash"></i> Yes, Remove Subject
          </button>
          <button type="button" class="btn btn-default btn-flat" data-dismiss="modal" style="background: linear-gradient(135deg, #006400 0%, #004d00 100%); color: #FFD700; border: none; border-radius: 6px; font-weight: 600; padding: 8px 20px;">
            <i class="fa fa-close"></i> Cancel
          </button>
        </div>
      </form>
    </div>
  </div>
</div>

<!-- Confirm Remove Book Modal -->
<div class="modal fade" id="confirmRemoveModal" tabindex="-1">
  <div class="modal-dialog">
    <div class="modal-content" style="border: 2px solid #8B0000; border-radius: 10px; overflow: hidden; box-shadow: 0 4px 12px rgba(139,0,0,0.3);">
      <form method="POST" action="subject_remove_book.php">
        <div class="modal-header" style="background: linear-gradient(135deg, #8B0000 0%, #A52A2A 100%); color: #FFD700; padding: 20px;">
          <h4 class="modal-title" style="font-weight: 700; margin: 0;">
            <i class="fa fa-exclamation-triangle" style="margin-right: 10px;"></i>Confirm Removal
          </h4>
          <button type="button" class="close" data-dismiss="modal" style="color: #FFD700; opacity: 0.8;">&times;</button>
        </div>
        <div class="modal-body" style="padding: 25px; background: linear-gradient(135deg, #fff8f8 0%, #ffffff 100%);">
          <p id="removeMessage" style="font-weight: 500; color: #8B0000;">Are you sure you want to remove this book from the subject?</p>
          <input type="hidden" name="subject_id" id="remove_subject_id">
          <input type="hidden" name="book_id" id="remove_book_id">
        </div>
        <div class="modal-footer" style="background: linear-gradient(135deg, #fff0f0 0%, #ffe8e8 100%); padding: 20px;">
          <button type="submit" name="confirm_remove" class="btn btn-danger btn-flat" style="background: linear-gradient(135deg, #ff6b6b 0%, #ee5a52 100%); color: white; border: none; border-radius: 6px; font-weight: 600; padding: 8px 20px;">
            <i class="fa fa-trash"></i> Yes, Remove
          </button>
          <button type="button" class="btn btn-default btn-flat" data-dismiss="modal" style="background: linear-gradient(135deg, #006400 0%, #004d00 100%); color: #FFD700; border: none; border-radius: 6px; font-weight: 600; padding: 8px 20px;">
            <i class="fa fa-close"></i> Cancel
          </button>
        </div>
      </form>
    </div>
  </div>
</div>

<!-- Assign Books Modal -->
<div class="modal fade" id="assignBooksModal" tabindex="-1" role="dialog">
  <div class="modal-dialog modal-lg" role="document">
    <div class="modal-content" style="border: 2px solid #006400; border-radius: 10px; overflow: hidden; box-shadow: 0 4px 12px rgba(0,100,0,0.3);">
      <div class="modal-header" style="background: linear-gradient(135deg, #006400 0%, #004d00 100%); color: #FFD700; padding: 20px;">
        <button type="button" class="close" data-dismiss="modal" style="color: #FFD700; opacity: 0.8;">&times;</button>
        <h4 class="modal-title" style="font-weight: 700; margin: 0;">
          <i class="fa fa-book" style="margin-right: 10px;"></i> Assign Books to Subject
        </h4>
      </div>
      <div class="modal-body" style="padding: 25px; background: linear-gradient(135deg, #f8fff8 0%, #ffffff 100%);">
        <input type="hidden" id="subject_id">
        <div class="form-group">
          <label style="font-weight: 600; color: #006400; margin-bottom: 8px;">
            <i class="fa fa-search" style="margin-right: 8px;"></i>Search Books
          </label>
          <input type="text" id="bookSearch" class="form-control" placeholder="Search books by call no., title, author, or published date..." style="border-radius: 6px; border: 1px solid #006400; padding: 10px;">
        </div>
        <div class="table-responsive">
          <table class="table table-bordered table-hover">
            <thead style="background: linear-gradient(135deg, #f0fff0 0%, #e0f7e0 100%);">
              <tr>
                <th style="width:50px; border-right: 1px solid #e0e0e0;">Select</th>
                <th style="border-right: 1px solid #e0e0e0;">📞 Call No.</th>
                <th style="border-right: 1px solid #e0e0e0;">📚 Title</th>
                <th style="border-right: 1px solid #e0e0e0;">✍️ Author</th>
                <th>📅 Published Date</th>
              </tr>
            </thead>
            <tbody id="booksListBody">
              <tr><td colspan="5" class="text-center text-muted" style="padding: 20px;">
                <i class="fa fa-search" style="margin-right: 8px;"></i>Search to display books...
              </td></tr>
            </tbody>
          </table>
        </div>
      </div>
      <div class="modal-footer" style="background: linear-gradient(135deg, #f0fff0 0%, #e0f7e0 100%); padding: 20px;">
        <button type="button" class="btn btn-success btn-flat" id="saveBooksBtn" style="background: linear-gradient(135deg, #32CD32 0%, #228B22 100%); color: white; border: none; border-radius: 6px; font-weight: 600; padding: 8px 20px;">
          <i class="fa fa-save"></i> Save Selection
        </button>
        <button type="button" class="btn btn-default btn-flat" data-dismiss="modal" style="background: linear-gradient(135deg, #006400 0%, #004d00 100%); color: #FFD700; border: none; border-radius: 6px; font-weight: 600; padding: 8px 20px;">
          <i class="fa fa-times"></i> Close
        </button>
      </div>
    </div>
  </div>
</div>


<script>
// 🔸 Sort Table Function
function sortTable(column) {
  const currentUrl = new URL(window.location);
  const currentSort = currentUrl.searchParams.get('sort');
  const currentOrder = currentUrl.searchParams.get('order') || 'ASC';

  // Toggle sort order if clicking the same column
  let newOrder = 'ASC';
  if (currentSort === column && currentOrder === 'ASC') {
    newOrder = 'DESC';
  }

  currentUrl.searchParams.set('sort', column);
  currentUrl.searchParams.set('order', newOrder);
  window.location = currentUrl.toString();
}

$(document).ready(function() {
  // 🔸 Get all existing subjects for duplicate checking
  let existingSubjects = [];
  $('#subjectsTable tbody tr').each(function() {
    const subjectName = $(this).find('td:eq(1)').text().replace(/\s+/g, ' ').trim().toLowerCase();
    // Extract the actual name (remove icon text)
    const cleanName = subjectName.replace(/[^\w\s]/g, '').trim();
    if (cleanName) {
      existingSubjects.push(cleanName);
    }
  });

  // 🔸 Live duplicate check on input
  $('#newSubjectName').on('keyup change', function() {
    const inputValue = $(this).val().trim().toLowerCase();
    const warning = $('#duplicateWarning');
    const submitBtn = $('#submitAddSubject');
    
    if (inputValue.length === 0) {
      warning.hide();
      submitBtn.prop('disabled', false).css('opacity', '1');
      return;
    }

    // Check if subject already exists (case insensitive)
    const isDuplicate = existingSubjects.some(subject => subject === inputValue);

    if (isDuplicate) {
      warning.show();
      submitBtn.prop('disabled', true).css('opacity', '0.5').attr('title', 'This subject already exists');
    } else {
      warning.hide();
      submitBtn.prop('disabled', false).css('opacity', '1').removeAttr('title');
    }
  });

  // 🔸 Prevent form submission if duplicate
  $('#addSubjectForm').on('submit', function(e) {
    const inputValue = $('#newSubjectName').val().trim().toLowerCase();
    const isDuplicate = existingSubjects.some(subject => subject === inputValue);

    if (isDuplicate) {
      e.preventDefault();
      const errorDiv = $('#addSubjectError');
      errorDiv.html('<i class="fa fa-exclamation-circle"></i> <strong>Duplicate Subject:</strong> This subject already exists in the system. Please enter a different subject name.').show();
      $('#newSubjectName').focus();
      return false;
    }
  });

  // 🔸 Clear error message when modal closes
  $('#addSubjectModal').on('hidden.bs.modal', function() {
    $('#addSubjectError').hide();
    $('#duplicateWarning').hide();
    $('#newSubjectName').val('').focus();
    $('#submitAddSubject').prop('disabled', false).css('opacity', '1');
  });

  // 🔸 Edit Subject
  function editSubject(id, name) {
    $('#edit_subject_id').val(id);
    $('#editSubjectName').val(name);
    $('#editSubjectModal').modal('show');
  }

  // 🔸 Remove Subject
  function removeSubject(id, name) {
    $('#remove_subject_id').val(id);
    $('#removeSubjectMessage').html(`Are you sure you want to remove <strong>${name}</strong>?`);
    $('#confirmRemoveSubjectModal').modal('show');
  }

  // 🔸 Assign Books
  $('.manageBooks').on('click', function() {
    $('#subject_id').val($(this).data('id'));
    $('#assignBooksModal').modal('show');
    $('#booksListBody').html('<tr><td colspan="5" class="text-center">Search to display books...</td></tr>');
  });

  // 🔸 Live search books
  $('#bookSearch').on('keyup', function() {
    const query = $(this).val().trim();
    const subjectId = $('#subject_id').val();
    if (query.length === 0) {
      $('#booksListBody').html('<tr><td colspan="5" class="text-center">Search to display books...</td></tr>');
      return;
    }
    $.ajax({
      url: 'fetch_books_for_subject.php',
      type: 'POST',
      data: { query: query, subject_id: subjectId },
      success: function(data) {
        $('#booksListBody').html(data);
      }
    });
  });

  // 🔸 Assign / Remove Book instantly
  $(document).on('change', '.book-checkbox', function() {
    const bookId = $(this).val();
    const subjectId = $('#subject_id').val();
    const isChecked = $(this).is(':checked');
    $.ajax({
      url: isChecked ? 'assign_book.php' : 'remove_book_assignment.php',
      type: 'POST',
      data: { book_id: bookId, subject_id: subjectId }
    });
  });

  // 🔸 Remove book from subject (from subject table)
  $(document).on('click', '.removeBookBtn', function() {
    const bookId = $(this).data('book-id');
    const subjectId = $(this).data('subject-id');
    $('#remove_book_id').val(bookId);
    $('#remove_subject_id').val(subjectId);
    $('#confirmRemoveModal').modal('show');
  });
});
</script>

</body>
</html>
