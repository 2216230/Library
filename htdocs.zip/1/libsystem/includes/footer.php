<footer id=bg class=" text-white text-center py-3 border-top border-warning mt-4">
  © <?php echo date('Y'); ?> Benguet State University – Bokod Campus | Library Management System
</footer>
