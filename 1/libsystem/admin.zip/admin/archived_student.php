<?php
include 'includes/session.php';
include 'includes/header.php';
?>
<body class="hold-transition skin-green sidebar-mini">
<div class="wrapper">

<?php include 'includes/navbar.php'; ?>
<?php include 'includes/menubar.php'; ?>

<div class="content-wrapper">
  <!-- Header -->
  <section class="content-header" style="background-color: #006400; color: #FFD700; padding: 15px; border-radius: 5px 5px 0 0;">
    <h1 style="font-weight: bold;">🎓 Archived Students</h1>
  </section>

  <!-- Content -->
  <section class="content" style="background-color: #F8FFF0; padding: 15px; border-radius: 0 0 5px 5px;">
    <?php
      if(isset($_SESSION['error'])){
        echo "<div class='alert alert-danger' style='background-color: #FF6347; color: white; font-weight: bold; padding:10px; border-radius:5px;'>".$_SESSION['error']."</div>";
        unset($_SESSION['error']);
      }
      if(isset($_SESSION['success'])){
        echo "<div class='alert alert-success' style='background-color: #32CD32; color: #006400; font-weight: bold; padding:10px; border-radius:5px;'>".$_SESSION['success']."</div>";
        unset($_SESSION['success']);
      }
    ?>
    <div class="box" style="border-top: 3px solid #006400; border-radius: 5px;">
      <div class="box-body" style="background-color: #FFFFFF; border-radius: 0 0 5px 5px;">
        <table class="table table-bordered table-striped">
          <thead style="background-color: #006400; color: #FFD700; font-weight: bold;">
            <th>Course</th>
            <th>Student ID</th>
            <th>Firstname</th>
            <th>Middlename</th>
            <th>Lastname</th>
            <th>Email</th>
            <th>Phone</th>
            <th>Tools</th>
          </thead>
          <tbody>
            <?php
              // Correct join with 'course' table
              $query = $conn->query("
                SELECT a.*, c.title AS course_title 
                FROM archived_students a
                LEFT JOIN course c ON a.course_id = c.id
                LIMIT 0, 25
              ");

              if($query->num_rows > 0){
                  while($row = $query->fetch_assoc()){
                      echo "
                      <tr>
                        <td>".htmlspecialchars($row['course_title'])."</td>
                        <td>".htmlspecialchars($row['student_id'])."</td>
                        <td>".htmlspecialchars($row['firstname'])."</td>
                        <td>".(!empty($row['middlename']) ? htmlspecialchars($row['middlename']) : '-')."</td>
                        <td>".htmlspecialchars($row['lastname'])."</td>
                        <td>".(!empty($row['email']) ? htmlspecialchars($row['email']) : '-')."</td>
                        <td>".(!empty($row['phone']) ? htmlspecialchars($row['phone']) : '-')."</td>
                        <td>
                          <!-- Restore Button -->
                          <form method='POST' action='restore_student.php' style='display:inline-block; margin-right:5px;'>
                            <input type='hidden' name='id' value='".$row['id']."'>
                            <button class='btn btn-success btn-sm' type='submit' style='background-color:#32CD32; color:white; font-weight:bold;'>
                              <i class='fa fa-undo'></i> Restore
                            </button>
                          </form>

                          <!-- Delete Permanently Button -->
                          <form method='POST' action='delete_student_permanently.php' style='display:inline-block;' onsubmit=\"return confirm('Are you sure you want to permanently delete this student?');\">
                            <input type='hidden' name='id' value='".$row['id']."'>
                            <button class='btn btn-danger btn-sm' type='submit' style='background-color:#FF6347; color:white; font-weight:bold;'>
                              <i class='fa fa-trash'></i> Delete
                            </button>
                          </form>
                        </td>
                      </tr>
                      ";
                  }
              } else {
                  echo "<tr><td colspan='8' class='text-center'>No archived students found</td></tr>";
              }
            ?>
          </tbody>
        </table>
      </div>
    </div>
  </section>
</div>

<?php include 'includes/scripts.php'; ?>
</body>
</html>
