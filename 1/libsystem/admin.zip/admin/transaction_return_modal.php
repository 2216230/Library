<div class="modal fade" id="returnModal" tabindex="-1" role="dialog">
    <div class="modal-dialog">
        <div class="modal-content">

            <form id="returnForm">

                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                    <h4 class="modal-title">
                        <i class="fa fa-undo"></i> Return Book
                    </h4>
                </div>

                <div class="modal-body">

                    <input type="hidden" id="return_transaction_id" name="id">

                    <p><strong>Borrower:</strong> <span id="return_borrower"></span></p>
                    <p><strong>Book Title:</strong> <span id="return_book_title"></span></p>
                    <p><strong>Borrowed Date:</strong> <span id="return_borrow_date"></span></p>
                    <p><strong>Due Date:</strong> <span id="return_due_date"></span></p>

                    <hr>

                    <div class="form-group">
                        <label>Return Date</label>
                        <input type="date" name="return_date" id="return_date" class="form-control"
                            value="<?php echo date('Y-m-d'); ?>" required>
                    </div>

                    <div class="form-group">
                        <label>Condition Upon Return</label>
                        <select id="return_condition" name="condition" class="form-control" required>
                            <option value="">Select...</option>
                            <option value="good">Good</option>
                            <option value="damaged">Damaged</option>
                            <option value="repair">For Repair</option>
                        </select>
                    </div>

                </div>

                <div class="modal-footer">
                    <button type="button" class="btn btn-default" data-dismiss="modal">
                        Close
                    </button>
                    <button type="submit" class="btn btn-success">
                        Confirm Return
                    </button>
                </div>

            </form>

        </div>
    </div>
</div>
