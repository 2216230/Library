<!-- Footer -->
<footer class="main-footer">
    <div class="pull-right hidden-xs">
        <b>All rights reserved</b>
    </div>
    <strong>Copyright &copy; 2024 <a href="https://bsu.edu.ph/bokod-campus/">BSU BOKOD CAMPUS</a></strong>
</footer>
