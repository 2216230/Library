<?php 
include 'includes/session.php';
include 'includes/conn.php';

if(!isset($_SESSION['admin'])){
    header('location: index.php');
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Disposal Report - Library System</title>
    <?php include 'includes/header.php'; ?>
    
    <style>
        @media print {
            .no-print, .navbar, .menubar, .content-header, .breadcrumb, .sidebar {
                display: none !important;
            }
            body {
                background: white !important;
                color: black !important;
                font-size: 11pt;
                margin: 0;
                padding: 10px;
            }
            .table {
                width: 100%;
                border-collapse: collapse;
            }
            .table th, .table td {
                border: 1px solid #000 !important;
                padding: 6px 4px !important;
                font-size: 10pt !important;
            }
            .table th {
                background: #f0f0f0 !important;
                color: #000 !important;
            }
            .btn {
                display: none !important;
            }
        }

        .filter-section {
            background: linear-gradient(135deg, #fff5f5 0%, #ffe0e0 100%);
            border: 1px solid #FF6347;
            border-radius: 10px;
            padding: 20px;
            margin-bottom: 25px;
            box-shadow: 0 2px 8px rgba(255,99,71,0.1);
        }

        .filter-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 15px;
            margin-bottom: 15px;
        }

        .filter-group label {
            font-weight: 700;
            color: #FF6347;
            display: block;
            margin-bottom: 8px;
        }

        .filter-group input,
        .filter-group select {
            width: 100%;
            padding: 10px;
            border: 2px solid #FF6347;
            border-radius: 6px;
            font-size: 13px;
        }

        .btn-filter {
            background: linear-gradient(135deg, #FF6347 0%, #DC143C 100%);
            color: white;
            border: none;
            padding: 10px 20px;
            border-radius: 6px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s;
        }

        .btn-filter:hover {
            transform: translateY(-2px);
            box-shadow: 0 4px 8px rgba(255,99,71,0.2);
        }

        .btn-export {
            background: linear-gradient(135deg, #FF6347 0%, #DC143C 100%);
            color: white;
            border: none;
            padding: 10px 20px;
            border-radius: 6px;
            font-weight: 600;
            cursor: pointer;
        }
    </style>
</head>
<body class="hold-transition skin-green sidebar-mini">
<div class="wrapper">
    <?php include 'includes/navbar.php'; ?>
    <?php include 'includes/menubar.php'; ?>

    <div class="content-wrapper">
        <!-- Header -->
        <section class="content-header" style="background: linear-gradient(135deg, #FF6347 0%, #DC143C 100%); color: white; padding: 20px; box-shadow: 0 4px 6px rgba(0,0,0,0.1);">
            <h1 style="font-weight: 800; margin: 0; font-size: 28px;">
                <i class="fa fa-trash" style="margin-right: 10px;"></i>Disposal Report
            </h1>
            <ol class="breadcrumb" style="background-color: transparent; margin: 10px 0 0 0; padding: 0; font-weight: 600;">
                <li style="color: rgba(255,255,255,0.8);">HOME</li>
                <li><a href="home.php" style="color: #FFD700;"><i class="fa fa-dashboard"></i> Dashboard</a></li>
                <li class="active" style="color: #FFD700;">Disposal Report</li>
            </ol>
        </section>

        <!-- Main Content -->
        <section class="content" style="padding: 20px;">

            <!-- Alerts -->
            <?php
            if(isset($_SESSION['error'])){
                echo "<div class='alert alert-danger alert-dismissible' style='background: linear-gradient(135deg, #ff6b6b 0%, #ee5a52 100%); color: white; border: none; border-radius: 8px; margin-bottom: 20px;'>
                    <button type='button' class='close' data-dismiss='alert'>&times;</button>
                    <i class='fa fa-warning'></i> ".$_SESSION['error']."
                </div>";
                unset($_SESSION['error']);
            }
            if(isset($_SESSION['success'])){
                echo "<div class='alert alert-success alert-dismissible' style='background: linear-gradient(135deg, #32CD32 0%, #28a428 100%); color: #003300; border: none; border-radius: 8px; margin-bottom: 20px;'>
                    <button type='button' class='close' data-dismiss='alert'>&times;</button>
                    <i class='fa fa-check'></i> ".$_SESSION['success']."
                </div>";
                unset($_SESSION['success']);
            }
            ?>

            <!-- Filter Section -->
            <div class="filter-section">
                <h3 style="color: #FF6347; font-weight: 700; margin-top: 0; margin-bottom: 15px;">Filter & Export</h3>
                <form method="get" style="display: grid; gap: 15px;">
                    <div class="filter-grid">
                        <div class="filter-group">
                            <label>Search (Call No. or Title)</label>
                            <input type="text" name="search" placeholder="Enter search term..." value="">
                        </div>
                    </div>
                    <div style="display: flex; gap: 10px;">
                        <button type="submit" class="btn-filter no-print">
                            <i class="fa fa-search"></i> Search
                        </button>
                        <button type="button" class="btn-export no-print" onclick="window.print()">
                            <i class="fa fa-print"></i> Print
                        </button>
                    </div>
                </form>
            </div>

            <!-- Report Card -->
            <div style="background: white; border-radius: 10px; box-shadow: 0 2px 8px rgba(255,99,71,0.1); overflow: hidden;">
                <div style="overflow-x: auto; padding: 20px;">
                    <table class="table table-striped table-hover" style="border-radius: 0; overflow: hidden; font-size: 14px; margin-bottom: 0;">
                        <thead style="background: linear-gradient(135deg, #FF6347 0%, #DC143C 100%); color: white; font-weight: 700;">
                            <tr>
                                <th style="color: white; padding: 13px 8px; font-weight: 700; font-size: 13px; white-space: nowrap;">Call No.</th>
                                <th style="color: white; padding: 13px 8px; font-weight: 700; font-size: 13px;">Title</th>
                                <th style="color: white; padding: 13px 8px; font-weight: 700; font-size: 13px; white-space: nowrap;">Author</th>
                                <th style="color: white; padding: 13px 8px; font-weight: 700; font-size: 13px; white-space: nowrap; text-align: center;">Damaged</th>
                                <th style="color: white; padding: 13px 8px; font-weight: 700; font-size: 13px; white-space: nowrap; text-align: center;">Lost</th>
                                <th style="color: white; padding: 13px 8px; font-weight: 700; font-size: 13px; white-space: nowrap; text-align: center;">Total Issues</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php 
                            // Get books with damaged or lost copies
                            $disposal_sql = "SELECT 
                                b.id,
                                b.call_no,
                                b.title,
                                b.author,
                                (SELECT COUNT(*) FROM book_copies WHERE book_id = b.id AND availability = 'damaged') as damaged_count,
                                (SELECT COUNT(*) FROM book_copies WHERE book_id = b.id AND availability = 'lost') as lost_count
                            FROM books b
                            WHERE EXISTS (
                                SELECT 1 FROM book_copies bc WHERE bc.book_id = b.id AND bc.availability IN ('damaged', 'lost')
                            )
                            ORDER BY b.call_no ASC";
                            
                            $disposal_result = $conn->query($disposal_sql);
                            
                            if ($disposal_result && $disposal_result->num_rows > 0) {
                                while ($book = $disposal_result->fetch_assoc()) {
                                    $total_issues = $book['damaged_count'] + $book['lost_count'];
                                    ?>
                                    <tr>
                                        <td style="padding: 10px 6px; font-size: 14px; font-weight: 600; color: #FF6347;"><?php echo htmlspecialchars($book['call_no']); ?></td>
                                        <td style="padding: 10px 6px; font-size: 14px; font-weight: 600;"><?php echo htmlspecialchars($book['title']); ?></td>
                                        <td style="padding: 10px 6px; font-size: 14px;"><?php echo htmlspecialchars($book['author'] ?: '-'); ?></td>
                                        <td style="padding: 10px 6px; font-size: 14px; text-align: center; background: #ffe0e0;"><strong style="color: #FF6347;"><?php echo $book['damaged_count']; ?></strong></td>
                                        <td style="padding: 10px 6px; font-size: 14px; text-align: center; background: #ffe0e0;"><strong style="color: #FF6347;"><?php echo $book['lost_count']; ?></strong></td>
                                        <td style="padding: 10px 6px; font-size: 14px; text-align: center; background: #fff3e0;"><strong style="color: #FF6347;"><?php echo $total_issues; ?></strong></td>
                                    </tr>
                                    <?php
                                }
                            } else {
                                echo "<tr><td colspan='6' style='text-align: center; padding: 30px; color: #666;'><i class='fa fa-check-circle'></i> No books with disposal issues</td></tr>";
                            }
                            ?>
                        </tbody>
                    </table>
                </div>
            </div>

        </section>
    </div>

    <?php include 'includes/footer.php'; ?>
</div>

<?php include 'includes/scripts.php'; ?>

</body>
</html>
