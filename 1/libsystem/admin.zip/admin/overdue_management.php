<?php
include 'includes/session.php';
include 'includes/conn.php';
include 'includes/overdue_notifier.php';

// Page title
$title = "Overdue Management";
date_default_timezone_set('Asia/Manila');

// Auto-send notifications once per day on first page load
$today = date('Y-m-d');
$last_run_file = __DIR__ . '/../../.last_notification_run';
$auto_sent = false;

if (!file_exists($last_run_file) || file_get_contents($last_run_file) !== $today) {
    $result = sendAllOverdueNotifications($conn);
    file_put_contents($last_run_file, $today);
    $auto_sent = true;
    $notification_message = "✅ Auto-sent {$result['sent']} overdue notification(s) at " . date('h:i A');
}

// Get today's notification count
$today_notified_count = getTodayNotificationCount($conn);

// Get all overdue transactions
$overdue_query = "
SELECT 
    bt.id,
    bt.borrower_type,
    bt.borrower_id,
    b.title AS book_title,
    b.call_no,
    bc.copy_number AS copy_no,
    bt.borrow_date,
    bt.due_date,
    bt.return_date,
    DATEDIFF(CURDATE(), bt.due_date) AS days_overdue,
    CONCAT(st.firstname, ' ', st.lastname) AS student_name,
    CONCAT(fc.firstname, ' ', fc.lastname) AS faculty_name,
    st.email AS student_email,
    fc.email AS faculty_email,
    st.student_id AS student_id,
    fc.faculty_id AS faculty_id
FROM borrow_transactions bt
LEFT JOIN books b ON bt.book_id = b.id
LEFT JOIN book_copies bc ON bt.copy_id = bc.id
LEFT JOIN students st ON bt.borrower_type = 'student' AND bt.borrower_id = st.id
LEFT JOIN faculty fc ON bt.borrower_type = 'faculty' AND bt.borrower_id = fc.id
WHERE bt.status = 'borrowed' AND DATE(bt.due_date) < CURDATE()
ORDER BY DATEDIFF(CURDATE(), bt.due_date) DESC
";

$overdue_result = $conn->query($overdue_query);
$overdue_count = $overdue_result->num_rows;

// Get summary statistics
$stats_query = "
SELECT 
    COUNT(*) AS total_overdue,
    COUNT(DISTINCT IF(bt.borrower_type='student', bt.borrower_id, NULL)) AS students_with_overdue,
    COUNT(DISTINCT IF(bt.borrower_type='faculty', bt.borrower_id, NULL)) AS faculty_with_overdue,
    SUM(DATEDIFF(CURDATE(), bt.due_date)) AS total_overdue_days
FROM borrow_transactions bt
WHERE bt.status = 'borrowed' AND DATE(bt.due_date) < CURDATE()
";

$stats_result = $conn->query($stats_query);
$stats = $stats_result->fetch_assoc();

// Get books due within 1 day (for advance notification)
$due_soon_query = "
SELECT 
    bt.id,
    bt.borrower_type,
    bt.borrower_id,
    b.title AS book_title,
    bt.due_date,
    DATEDIFF(bt.due_date, CURDATE()) AS days_until_due,
    CONCAT(st.firstname, ' ', st.lastname) AS student_name,
    CONCAT(fc.firstname, ' ', fc.lastname) AS faculty_name,
    st.email AS student_email,
    fc.email AS faculty_email,
    st.student_id AS student_id,
    fc.faculty_id AS faculty_id
FROM borrow_transactions bt
LEFT JOIN books b ON bt.book_id = b.id
LEFT JOIN students st ON bt.borrower_type = 'student' AND bt.borrower_id = st.id
LEFT JOIN faculty fc ON bt.borrower_type = 'faculty' AND bt.borrower_id = fc.id
WHERE bt.status = 'borrowed' 
AND bt.due_date >= CURDATE() 
AND bt.due_date <= DATE_ADD(CURDATE(), INTERVAL 1 DAY)
ORDER BY bt.due_date ASC
";

$due_soon_result = $conn->query($due_soon_query);
$due_soon_count = $due_soon_result->num_rows;
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title><?php echo $title; ?> | Library System</title>
    <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
    <?php include 'includes/header.php'; ?>
    <style>
        /* ==================== OVERDUE MANAGEMENT STYLES ==================== */
        
        .box {
            margin-bottom: 15px;
            border-top: none;
        }

        .box-header {
            padding: 10px 15px !important;
            border-bottom: 1px solid #f4f4f4;
        }

        .box-header.with-border {
            border-bottom: 2px solid #228B22 !important;
        }

        .box-title {
            font-size: 16px !important;
            font-weight: 600 !important;
        }

        .box-body {
            padding: 15px !important;
        }

        .overdue-badge {
            background-color: #FF6347;
            color: white;
            padding: 6px 12px;
            border-radius: 20px;
            font-weight: bold;
            font-size: 12px;
            display: inline-block;
        }

        .stat-box {
            background: linear-gradient(135deg, #FF6347 0%, #FF4500 100%);
            color: white;
            padding: 12px 10px;
            border-radius: 6px;
            margin-bottom: 0;
            box-shadow: 0 2px 6px rgba(0,0,0,0.1);
            height: 100%;
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
            text-align: center;
        }

        .stat-box h4 {
            margin: 0;
            font-size: 32px;
            font-weight: bold;
            line-height: 1;
        }

        .stat-box p {
            margin: 6px 0 0 0;
            font-size: 13px;
            opacity: 0.95;
            font-weight: 500;
        }

        /* Table responsive */
        .table {
            font-size: 12px;
            margin-bottom: 0;
        }

        .table thead th {
            padding: 8px 5px;
            font-weight: 600;
            white-space: nowrap;
            background-color: #f5f5f5;
            border: none;
        }

        .table tbody td {
            padding: 8px 5px;
            vertical-align: middle;
            border: none;
        }

        .table tbody tr {
            border-bottom: 1px solid #f0f0f0;
        }

        .overdue-row {
            border-left: 4px solid #FF6347;
        }

        .days-badge {
            font-weight: bold;
            padding: 4px 8px;
            border-radius: 4px;
            background: #FFE4E1;
            color: #FF6347;
            font-size: 11px;
            display: inline-block;
        }

        .contact-badge {
            background: #E8F4F8;
            padding: 4px 8px;
            border-radius: 3px;
            font-size: 11px;
            cursor: pointer;
        }

        .btn-sm {
            padding: 4px 6px;
            font-size: 11px;
        }

        /* Content responsive */
        .content {
            padding: 15px !important;
        }

        .content-header {
            padding: 15px !important;
            margin-bottom: 15px;
        }

        .content-header h1 {
            font-size: 24px !important;
            margin: 0 0 10px 0 !important;
        }

        .breadcrumb {
            font-size: 12px;
            margin: 10px 0 0 0 !important;
            flex-wrap: wrap;
        }

        /* ==================== MOBILE DEVICES (< 576px) ==================== */
        @media (max-width: 575.98px) {
            .content {
                padding: 10px !important;
            }

            .content-header {
                padding: 10px !important;
            }

            .content-header h1 {
                font-size: 18px !important;
            }

            .breadcrumb {
                display: none;
            }

            .box-header {
                padding: 8px 10px !important;
            }

            .box-body {
                padding: 10px !important;
            }

            .table {
                font-size: 11px;
            }

            .table thead th {
                padding: 6px 3px;
            }

            .table tbody td {
                padding: 6px 3px;
            }

            .btn-sm {
                padding: 3px 5px;
                font-size: 10px;
            }

            .stat-box h4 {
                font-size: 24px;
            }

            .stat-box p {
                font-size: 12px;
            }

            /* Stack layout on mobile - vertical */
            div[style*="grid-template-columns: 1fr 280px 280px"] {
                grid-template-columns: 1fr !important;
            }

            /* Stats grid 2x2 on mobile */
            div[style*="grid-template-columns: repeat(2, 1fr)"] {
                grid-template-columns: repeat(2, 1fr) !important;
            }
        }

        /* ==================== TABLETS (576px - 991px) ==================== */
        @media (min-width: 576px) and (max-width: 991.98px) {
            /* Stack widgets on tablets */
            div[style*="grid-template-columns: 1fr 280px 280px"] {
                grid-template-columns: 1fr 1fr !important;
            }

            /* Stats stay 2x2 */
            div[style*="grid-template-columns: repeat(2, 1fr)"] {
                grid-template-columns: repeat(2, 1fr) !important;
            }
        }

        /* ==================== RESPONSIVE GRID FOR DASHBOARD ==================== */
        .dashboard-grid {
            display: grid;
            gap: 15px;
            margin-bottom: 30px;
            align-items: start;
        }

        /* Desktop: 4 columns */
        @media (min-width: 1200px) {
            .dashboard-grid {
                grid-template-columns: 1fr 1fr 1fr 1fr;
            }
        }

        /* Large tablets: 2 columns */
        @media (min-width: 992px) and (max-width: 1199.98px) {
            .dashboard-grid {
                grid-template-columns: 1fr 1fr;
            }
        }

        /* Tablets: 1 column */
        @media (min-width: 768px) and (max-width: 991.98px) {
            .dashboard-grid {
                grid-template-columns: 1fr;
            }
        }

        /* Small devices: 1 column, stacked */
        @media (max-width: 767.98px) {
            .dashboard-grid {
                grid-template-columns: 1fr;
            }

            .stat-box {
                padding: 10px 8px !important;
            }

            .stat-box h4 {
                font-size: 24px !important;
            }

            .stat-box p {
                font-size: 11px !important;
            }

            .box {
                margin-bottom: 10px !important;
            }

            .box-body {
                padding: 10px !important;
            }
        }
    </style>
</head>
<body class="hold-transition skin-green sidebar-mini">
<div class="wrapper">
    <?php include 'includes/navbar.php'; ?>
    <?php include 'includes/menubar.php'; ?>

    <div class="content-wrapper">
        <section class="content-header" style="background: linear-gradient(135deg, #FF6347 0%, #FF4500 100%); color: white; padding: 20px; box-shadow: 0 4px 6px rgba(0,0,0,0.1);">
            <h1 style="font-weight: 800; margin: 0; font-size: 28px; text-shadow: 2px 2px 4px rgba(0,0,0,0.3);">
                <i class="fa fa-clock-o" style="margin-right: 10px;"></i>Overdue Management
            </h1>
            <ol class="breadcrumb" style="background-color: transparent; margin: 10px 0 0 0; padding: 0; font-weight: 600;">
                <li style="color: white;">COMMUNICATIONS</li>
                <li style="color: #FFE4B5;"><i class="fa fa-clock-o"></i> Overdue Management</li>
            </ol>
        </section>

        <section class="content">
            <!-- Notification Alert -->
            <?php if (isset($notification_message)): ?>
            <div style="background: linear-gradient(135deg, #4CAF50 0%, #45a049 100%); color: white; padding: 15px 20px; border-radius: 8px; margin-bottom: 20px; box-shadow: 0 3px 10px rgba(0,0,0,0.1); display: flex; align-items: center; justify-content: space-between;">
                <div>
                    <h4 style="margin: 0 0 5px 0; font-weight: 700;"><i class="fa fa-check-circle"></i> Success</h4>
                    <p style="margin: 0; font-size: 13px;"><?php echo htmlspecialchars($notification_message); ?></p>
                </div>
            </div>
            <?php endif; ?>

            <!-- Statistics Section -->
            <!-- Stats and Widgets Row - All in One Line -->
            <div class="dashboard-grid">
                <!-- Stats Cards 1 Column - Left Side -->
                <div>
                    <div style="display: grid; grid-template-columns: repeat(1, 1fr); gap: 12px;">
                        <div>
                            <div class="stat-box" style="background: linear-gradient(135deg, #FF6347 0%, #FF4500 100%);">
                                <div style="display: flex; align-items: center; justify-content: space-between;">
                                    <div>
                                        <h4><?php echo $stats['total_overdue']; ?></h4>
                                        <p>Total Overdue</p>
                                    </div>
                                    <i class="fa fa-exclamation-circle" style="font-size: 36px; opacity: 0.3;"></i>
                                </div>
                            </div>
                        </div>
                        <div>
                            <div class="stat-box" style="background: linear-gradient(135deg, #FF8C69 0%, #FF6347 100%);">
                                <div style="display: flex; align-items: center; justify-content: space-between;">
                                    <div>
                                        <h4><?php echo $stats['students_with_overdue']; ?></h4>
                                        <p>Students</p>
                                    </div>
                                    <i class="fa fa-graduation-cap" style="font-size: 36px; opacity: 0.3;"></i>
                                </div>
                            </div>
                        </div>
                        <div>
                            <div class="stat-box" style="background: linear-gradient(135deg, #FFA07A 0%, #FF8C69 100%);">
                                <div style="display: flex; align-items: center; justify-content: space-between;">
                                    <div>
                                        <h4><?php echo $stats['faculty_with_overdue']; ?></h4>
                                        <p>Faculty</p>
                                    </div>
                                    <i class="fa fa-users" style="font-size: 36px; opacity: 0.3;"></i>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- NOTIFICATION WIDGET -->
                <div>
                    <div class="box" style="border-top: 3px solid #2196F3; box-shadow: 0 2px 8px rgba(0,0,0,0.1); height: 100%;">
                        <div class="box-header with-border" style="background: linear-gradient(135deg, #E3F2FD 0%, #BBDEFB 100%); border-bottom: 2px solid #2196F3; padding: 12px 15px;">
                            <h4 class="box-title" style="color: #1976D2; font-weight: 600; margin: 0; font-size: 13px;">
                                <i class="fa fa-bell"></i> Notifications
                            </h4>
                        </div>
                        <div class="box-body" style="padding: 12px;">
                            <div style="background: linear-gradient(135deg, #2196F3 0%, #1976D2 100%); color: white; padding: 14px 12px; border-radius: 6px; margin-bottom: 12px; text-align: center;">
                                <p style="margin: 0 0 4px 0; font-size: 10px; opacity: 0.9; font-weight: 500;">Today's Sent</p>
                                <h3 style="margin: 0; font-size: 32px; font-weight: bold; line-height: 1;"><?php echo $today_notified_count; ?></h3>
                            </div>

                            <div style="background: #E3F2FD; padding: 10px; border-radius: 5px; border-left: 3px solid #2196F3; font-size: 10px; color: #1565C0; line-height: 1.6;">
                                <p style="margin: 0 0 6px 0;"><strong><i class="fa fa-info-circle"></i> Auto-send Status</strong></p>
                                <div style="background: white; padding: 6px 8px; border-radius: 3px;">
                                    <p style="margin: 0;"><i class="fa fa-check-circle" style="color: #4CAF50;"></i> <strong>Active</strong></p>
                                    <p style="margin: 3px 0 0 0; font-size: 9px; color: #0D47A1;">Sends daily at page load</p>
                                </div>
                            </div>

                            <!-- Message display after sending -->
                            <div id="overdueNotificationMessage" style="margin-top: 10px; padding: 8px; border-radius: 4px; font-size: 11px; display: none;">
                            </div>
                        </div>
                    </div>
                </div>

                <!-- DUE DATE MONITORING WIDGET -->
                <div>
                    <div class="box" style="border-top: 3px solid #4CAF50; box-shadow: 0 2px 8px rgba(0,0,0,0.1); height: 100%;">
                        <div class="box-header with-border" style="background: linear-gradient(135deg, #E8F5E9 0%, #C8E6C9 100%); border-bottom: 2px solid #4CAF50; padding: 12px 15px;">
                            <h4 class="box-title" style="color: #2E7D32; font-weight: 600; margin: 0; font-size: 13px;">
                                <i class="fa fa-calendar"></i> Due Date Monitoring
                            </h4>
                        </div>
                        <div class="box-body" style="padding: 12px;">
                            <div style="background: linear-gradient(135deg, #4CAF50 0%, #388E3C 100%); color: white; padding: 14px 12px; border-radius: 6px; margin-bottom: 12px; text-align: center;">
                                <p style="margin: 0 0 4px 0; font-size: 10px; opacity: 0.9; font-weight: 500;">Books Due Soon</p>
                                <h3 id="due-soon-count" style="margin: 0; font-size: 32px; font-weight: bold; line-height: 1;"><?php echo $due_soon_count; ?></h3>
                            </div>

                            <div style="background: #F1F8E9; padding: 10px; border-radius: 5px; border-left: 3px solid #4CAF50; font-size: 10px; color: #33691E; line-height: 1.6;">
                                <p style="margin: 0 0 6px 0;"><strong><i class="fa fa-info-circle"></i> Auto-send Status</strong></p>
                                <div style="background: white; padding: 6px 8px; border-radius: 3px; margin-bottom: 5px;">
                                    <p style="margin: 0;"><i class="fa fa-check-circle" style="color: #4CAF50;"></i> <strong>Active</strong></p>
                                    <p style="margin: 3px 0 0 0; font-size: 9px; color: #2E7D32;">Sends daily at page load</p>
                                </div>
                                <div style="background: white; padding: 6px 8px; border-radius: 3px; margin-top: 5px;">
                                    <p style="margin: 0;"><strong>Schedule:</strong></p>
                                    <p style="margin: 3px 0 0 0; font-size: 9px; color: #558B2F;">• 1 day before due date</p>
                                    <p style="margin: 3px 0 0 0; font-size: 9px; color: #558B2F;">• On due date</p>
                                </div>
                            </div>
                            
                            <!-- Message display after sending -->
                            <div id="dueNotificationMessage" style="margin-top: 10px; padding: 8px; border-radius: 4px; font-size: 11px; display: none;">
                            </div>
                        </div>
                    </div>
                </div>

                <!-- FINES WIDGET -->
                <div>
                    <div class="box" style="border-top: 3px solid #FF9800; box-shadow: 0 2px 8px rgba(0,0,0,0.1); height: 100%;">
                        <div class="box-header with-border" style="background: linear-gradient(135deg, #FFF3E0 0%, #FFE0B2 100%); border-bottom: 2px solid #FF9800; padding: 12px 15px;">
                            <h4 class="box-title" style="color: #E65100; font-weight: 600; margin: 0; font-size: 13px;">
                                <i class="fa fa-credit-card"></i> Fine Configuration
                            </h4>
                        </div>
                        <div class="box-body" style="padding: 12px;">
                            <div style="background: #FFF8E1; padding: 10px; border-radius: 5px; margin-bottom: 12px;">
                                <p style="margin: 0 0 8px 0; font-size: 11px; color: #666; font-weight: 500;">Amount per day:</p>
                                <div style="display: flex; gap: 8px; align-items: center;">
                                    <span style="font-size: 12px; color: #F57C00; font-weight: 600;">₱</span>
                                    <input type="number" id="fineAmount" value="10" step="0.50" min="0" style="flex: 1; padding: 7px 8px; border: 1px solid #FFD699; border-radius: 4px; font-size: 13px; font-weight: 600; background: white;">
                                    <button id="saveFineBtn" class="btn btn-sm btn-primary" style="padding: 6px 10px; font-size: 10px; background-color: #FF9800; border: none; color: white;" title="Save fine amount">
                                        <i class="fa fa-save"></i>
                                    </button>
                                </div>
                            </div>
                            <div style="background: #F3E5F5; padding: 10px; border-radius: 5px; border-left: 3px solid #9C27B0; font-size: 10px; color: #555; line-height: 1.5;">
                                <p style="margin: 0 0 5px 0;"><strong><i class="fa fa-ban"></i> Excluding:</strong></p>
                                <ul style="margin: 0; padding-left: 18px;">
                                    <li style="margin: 2px 0;">Sundays</li>
                                    <li style="margin: 2px 0;">Holidays</li>
                                    <li style="margin: 2px 0;">Suspensions</li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- TAB PANES FOR OVERDUES AND SETTLEMENT RECORDS -->
            <div class="nav-tabs-custom" style="margin-bottom: 0;">
                <!-- Tab Navigation -->
                <ul class="nav nav-tabs" style="background: white; border-bottom: 2px solid #FF6347; border-radius: 4px 4px 0 0;">
                    <li class="active" style="margin-right: 2px;">
                        <a href="#overdues-tab" data-toggle="tab" style="background: #FF6347; color: white; border: none; border-radius: 4px 4px 0 0; font-weight: 600;">
                            <i class="fa fa-exclamation-circle"></i> Overdue Books
                        </a>
                    </li>
                    <li style="margin-right: 2px;">
                        <a href="#settlement-records-tab" data-toggle="tab" style="background: #4CAF50; color: white; border: none; border-radius: 4px 4px 0 0; font-weight: 600;">
                            <i class="fa fa-history"></i> Settlement Records
                        </a>
                    </li>
                </ul>

                <!-- Tab Content -->
                <div class="tab-content">
                    <!-- OVERDUES TAB -->
                    <div class="tab-pane active" id="overdues-tab">
                        <div style="padding: 20px; background: white; border-radius: 0 0 6px 6px; box-shadow: 0 2px 8px rgba(0,0,0,0.08);">
                            <div class="box" style="border-top: 3px solid #FF6347; margin-bottom: 0; box-shadow: none;">
                                <div class="box-header with-border" style="background: linear-gradient(135deg, #f9f9f9 0%, #f5f5f5 100%); padding: 15px;">
                                    <h3 class="box-title" style="color: #FF6347; font-weight: 600; margin: 0;">
                                        <i class="fa fa-list"></i> Overdue Transactions
                                    </h3>
                                    <div class="box-tools pull-right">
                                        <span class="overdue-badge"><?php echo $overdue_count; ?> items</span>
                                    </div>
                                </div>

                                <div class="box-body" style="padding: 15px;">
                            <?php if ($overdue_count > 0): ?>
                                <div class="table-responsive">
                                    <table class="table table-striped table-hover" style="margin-bottom: 0;">
                                        <thead style="background-color: #f5f5f5; color: #333;">
                                            <tr>
                                                <th style="width: 8%;">Days Overdue</th>
                                                <th style="width: 12%;">Borrower</th>
                                                <th style="width: 8%;">Type</th>
                                                <th style="width: 15%;">Book Title</th>
                                                <th style="width: 10%;">Call No.</th>
                                                <th style="width: 10%;">Due Date</th>
                                                <th style="width: 15%;">Last Notified</th>
                                                <th style="width: 10%;">Contact</th>
                                                <th style="width: 20%;">Actions</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                <?php while ($row = $overdue_result->fetch_assoc()): ?>
                                    <tr class="overdue-row" data-id="<?php echo $row['id']; ?>">
                                        <td>
                                            <span class="days-badge">
                                                <?php echo $row['days_overdue']; ?> <?php echo $row['days_overdue'] == 1 ? 'day' : 'days'; ?>
                                            </span>
                                            </td>
                                            <td>
                                                <strong><?php echo htmlspecialchars($row['borrower_type'] === 'student' ? $row['student_name'] : $row['faculty_name']); ?></strong><br>
                                                <small style="color: #666;">
                                                    <?php echo $row['borrower_type'] === 'student' ? $row['student_id'] : $row['faculty_id']; ?>
                                                </small>
                                            </td>
                                            <td>
                                                <?php echo ucfirst($row['borrower_type']); ?>
                                            </td>
                                            <td>
                                                <strong><?php echo htmlspecialchars($row['book_title']); ?></strong>
                                            </td>
                                            <td>
                                                <code><?php echo htmlspecialchars($row['call_no']); ?></code>
                                            </td>
                                            <td>
                                                <span style="color: #FF6347; font-weight: bold;">
                                                    <?php echo date('M d, Y', strtotime($row['due_date'])); ?>
                                                </span>
                                            </td>
                                            <td>
                                                <?php 
                                                    $notif_date = getLastNotificationDate($conn, $row['id']);
                                                    if ($notif_date !== 'Not yet notified') {
                                                        echo "<span style='background: #C8E6C9; color: #2E7D32; padding: 4px 8px; border-radius: 3px; font-size: 11px;'><i class='fa fa-check'></i> " . $notif_date . "</span>";
                                                    } else {
                                                        echo "<span style='background: #FFEBEE; color: #C62828; padding: 4px 8px; border-radius: 3px; font-size: 11px;'><i class='fa fa-times'></i> " . $notif_date . "</span>";
                                                    }
                                                ?>
                                            </td>
                                            <td>
                                                <span class="contact-badge">
                                                    <i class="fa fa-envelope"></i>
                                                    <?php echo $row['borrower_type'] === 'student' ? htmlspecialchars($row['student_email']) : htmlspecialchars($row['faculty_email']); ?>
                                                </span>
                                            </td>
                                            <td>
                                                <div class="btn-group" role="group">
                                                    <button class="btn btn-success btn-sm" title="Mark as Returned">
                                                        Settle
                                                    </button>
                                                </div>
                                            </td>
                                        </tr>
                                    <?php endwhile; ?>
                                        </tbody>
                                    </table>
                                </div>
                                <!-- PAGINATION FOR OVERDUE BOOKS -->
                                <div style="margin-top: 15px; display: flex; justify-content: space-between; align-items: center; padding: 0 15px;">
                                    <div style="font-size: 12px; color: #666;">
                                        Showing <span id="overdue-start">1</span> to <span id="overdue-end">10</span> of <span id="overdue-total"><?php echo $overdue_count; ?></span> records
                                    </div>
                                    <nav>
                                        <ul class="pagination pagination-sm" id="overdue-pagination" style="margin: 0;">
                                        </ul>
                                    </nav>
                                </div>
                            <?php else: ?>
                                <div class="alert alert-success" style="border-radius: 5px;">
                                    <h4><i class="fa fa-check-circle"></i> Great News!</h4>
                                    <p style="margin-bottom: 0;">There are no overdue books at the moment. All borrowers are in good standing!</p>
                                </div>
                            <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- SETTLEMENT RECORDS TAB -->
                    <div class="tab-pane" id="settlement-records-tab">
                        <div style="padding: 20px; background: white; border-radius: 0 0 6px 6px; box-shadow: 0 2px 8px rgba(0,0,0,0.08);">
                            <div class="box" style="border-top: 3px solid #4CAF50; margin-bottom: 0; box-shadow: none;">
                                <div class="box-header with-border" style="background: linear-gradient(135deg, #f9f9f9 0%, #f5f5f5 100%); padding: 15px;">
                                    <h3 class="box-title" style="color: #4CAF50; font-weight: 600; margin: 0;">
                                        <i class="fa fa-history"></i> Settlement History & Details
                                    </h3>
                                    <div class="box-tools pull-right">
                                        <span class="settlement-badge" id="settlement-count-badge">0 records</span>
                                    </div>
                                </div>

                                <div class="box-body" style="padding: 15px;">
                                    <div class="table-responsive">
                                        <table class="table table-striped table-hover" id="settlement-records-table" style="margin-bottom: 0;">
                                            <thead style="background-color: #f5f5f5; color: #333;">
                                                <tr>
                                                    <th style="width: 10%;">Settlement Date</th>
                                                    <th style="width: 12%;">Borrower</th>
                                                    <th style="width: 15%;">Book Title</th>
                                                    <th style="width: 8%;">Days Overdue</th>
                                                    <th style="width: 8%;">Fine/Day</th>
                                                    <th style="width: 8%;">Calculated Fine</th>
                                                    <th style="width: 12%;">Adjustment</th>
                                                    <th style="width: 10%;">Total Payable</th>
                                                    <th style="width: 10%;">Status</th>
                                                    <th style="width: 7%;">Action</th>
                                                </tr>
                                            </thead>
                                            <tbody id="settlement-records-body">
                                                <tr>
                                                    <td colspan="10" style="text-align: center; padding: 40px; color: #999;">
                                                        <i class="fa fa-spinner fa-spin" style="font-size: 24px; margin-bottom: 10px;"></i><br>
                                                        Loading settlement records...
                                                    </td>
                                                </tr>
                                            </tbody>
                                        </table>
                                    </div>
                                    <!-- PAGINATION FOR SETTLEMENT RECORDS -->
                                    <div style="margin-top: 15px; display: flex; justify-content: space-between; align-items: center; padding: 0 15px; border-top: 1px solid #f0f0f0; padding-top: 15px;">
                                        <div style="font-size: 12px; color: #666;">
                                            Showing <span id="settlement-start">0</span> to <span id="settlement-end">0</span> of <span id="settlement-total">0</span> records
                                        </div>
                                        <nav>
                                            <ul class="pagination pagination-sm" id="settlement-pagination" style="margin: 0;">
                                            </ul>
                                        </nav>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </div>

    <?php include 'includes/footer.php'; ?>
    <?php include 'includes/scripts.php'; ?>

    <!-- SETTLE/RETURN MODAL -->
    <div class="modal fade" id="settleModal" tabindex="-1" role="dialog" aria-labelledby="settleModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-lg" role="document" style="max-width: 900px;">
            <div class="modal-content" style="border-top: 4px solid #4CAF50;">
                <div class="modal-header" style="background: linear-gradient(135deg, #E8F5E9 0%, #C8E6C9 100%); border-bottom: 2px solid #4CAF50;">
                    <h5 class="modal-title" id="settleModalLabel" style="color: #2E7D32; font-weight: 600;">
                        <i class="fa fa-check-circle"></i> Settle Overdue Book
                    </h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body" style="padding: 20px;">
                    <form id="settleForm">
                        <input type="hidden" id="settle_transaction_id" name="id">

                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label style="font-weight: 600; color: #333;">Borrower</label>
                                    <p id="settle_borrower_name" style="margin: 5px 0; padding: 8px; background: #F5F5F5; border-radius: 4px; font-size: 13px;"></p>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label style="font-weight: 600; color: #333;">Book Title</label>
                                    <p id="settle_book_title" style="margin: 5px 0; padding: 8px; background: #F5F5F5; border-radius: 4px; font-size: 13px;"></p>
                                </div>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-md-3">
                                <div class="form-group">
                                    <label style="font-weight: 600; color: #333; font-size: 13px;">Days Overdue</label>
                                    <p id="settle_days_overdue" style="margin: 5px 0; padding: 8px; background: #FFF3E0; border-radius: 4px; color: #E65100; font-weight: 600; font-size: 13px;"></p>
                                </div>
                            </div>
                            <div class="col-md-3">
                                <div class="form-group">
                                    <label style="font-weight: 600; color: #333; font-size: 13px;">Due Date</label>
                                    <p id="settle_due_date" style="margin: 5px 0; padding: 8px; background: #F5F5F5; border-radius: 4px; font-size: 13px;"></p>
                                </div>
                            </div>
                            <div class="col-md-2">
                                <div class="form-group">
                                    <label style="font-weight: 600; color: #333; font-size: 12px;">Fine/Day (₱)</label>
                                    <input type="number" id="settle_fine_per_day" step="0.50" min="0" style="width: 100%; padding: 6px; border: 1px solid #DDD; border-radius: 4px; font-size: 12px; font-weight: 600;">
                                </div>
                            </div>
                            <div class="col-md-2">
                                <div class="form-group">
                                    <label style="font-weight: 600; color: #333; font-size: 12px;">Chargeable Days</label>
                                    <input type="number" id="settle_chargeable_days" min="0" style="width: 100%; padding: 6px; border: 1px solid #DDD; border-radius: 4px; font-size: 12px; font-weight: 600;">
                                </div>
                            </div>
                            <div class="col-md-2">
                                <div class="form-group">
                                    <label style="font-weight: 600; color: #FF6347; font-size: 12px;">Calc. Fine (₱)</label>
                                    <p id="settle_calculated_fine" style="margin: 5px 0; padding: 6px; background: #FFEBEE; border-radius: 4px; color: #C62828; font-weight: 600; font-size: 12px;">₱0.00</p>
                                </div>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-md-4">
                                <div class="form-group">
                                    <label for="settle_adjustment_reason" style="font-weight: 600; color: #333; font-size: 13px;">Adjustment Reason</label>
                                    <select id="settle_adjustment_reason" class="form-control" style="font-size: 12px;">
                                        <option value="">-- Select Reason --</option>
                                        <option value="exclusion">Excluded Days (Sundays/Holidays/Suspensions)</option>
                                        <option value="discount">Discount</option>
                                        <option value="waived">Waived/Promotional</option>
                                        <option value="lost_book">Lost Book (Book Cost: ₱</option>
                                        <option value="partial_return">Partial Return/Damage</option>
                                    </select>
                                </div>
                            </div>
                            <div class="col-md-3">
                                <div class="form-group">
                                    <label style="font-weight: 600; color: #333; font-size: 13px;">Amount (₱)</label>
                                    <div style="display: flex; gap: 4px; align-items: center;">
                                        <span id="settle_adjustment_symbol" style="font-size: 11px; color: #999; min-width: 50px;">Deduct:</span>
                                        <input type="number" id="settle_adjustment" step="0.50" min="0" value="0" style="flex: 1; padding: 6px; border: 1px solid #DDD; border-radius: 4px; font-size: 12px;">
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-5">
                                <div class="form-group">
                                    <label for="settle_return_date" style="font-weight: 600; color: #333; font-size: 13px;">Return Date</label>
                                    <input type="date" id="settle_return_date" name="return_date" class="form-control" style="font-size: 12px;" required>
                                </div>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-md-12">
                                <div class="form-group">
                                    <label for="settle_adjustment_details" style="font-weight: 600; color: #333; font-size: 13px;">Adjustment Details</label>
                                    <textarea id="settle_adjustment_details" class="form-control" rows="2" placeholder="e.g., Excluded 2 Sundays and 1 holiday, or Book replacement cost ₱500" style="font-size: 12px;"></textarea>
                                </div>
                            </div>
                        </div>

                        <div style="background: #E8F5E9; padding: 12px; border-radius: 6px; border-left: 4px solid #4CAF50; margin: 12px 0;">
                            <div style="display: flex; justify-content: space-between; margin-bottom: 6px; font-size: 13px;">
                                <span style="color: #2E7D32; font-weight: 600;">Calculated Fine:</span>
                                <span id="settle_calc_display" style="color: #2E7D32; font-weight: 600;">₱0.00</span>
                            </div>
                            <div style="display: flex; justify-content: space-between; margin-bottom: 6px; padding-bottom: 6px; border-bottom: 1px solid #C8E6C9; font-size: 13px;">
                                <span id="settle_adj_label" style="color: #666;">Adjustment:</span>
                                <span id="settle_adj_display" style="color: #D32F2F;">₱0.00</span>
                            </div>
                            <div style="display: flex; justify-content: space-between; font-size: 14px;">
                                <span style="color: #1565C0; font-weight: 700;">TOTAL PAYABLE:</span>
                                <span id="settle_total_payable" style="color: #1565C0; font-weight: 700;">₱0.00</span>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="settle_status" style="font-weight: 600; color: #333; font-size: 13px;">Return Status</label>
                                    <select id="settle_status" name="status" class="form-control" style="font-size: 12px;" required>
                                        <option value="returned">Returned (Good Condition)</option>
                                        <option value="damaged">Returned (Damaged)</option>
                                        <option value="lost">Lost/Not Returned</option>
                                    </select>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="alert alert-info" style="margin: 0; padding: 8px; font-size: 11px;">
                                    <i class="fa fa-info-circle"></i> <strong>Fine will be calculated</strong> based on overdue days
                                </div>
                            </div>
                        </div>
                    </form>
                </div>
                <div class="modal-footer" style="background: #F5F5F5; border-top: 1px solid #E0E0E0;">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">
                        <i class="fa fa-times"></i> Cancel
                    </button>
                    <button type="submit" form="settleForm" class="btn btn-success" style="background-color: #4CAF50; border: none;">
                        <i class="fa fa-check"></i> Settle & Mark Returned
                    </button>
                </div>
            </div>
        </div>
    </div>
    
    <script>
    // Alert Modal Function
    function showAlertModal(type, title, message) {
        let alertClass = 'alert-info';
        let iconClass = 'fa-info-circle';
        let bgColor = '#E3F2FD';
        let borderColor = '#2196F3';
        let titleColor = '#1565C0';

        if (type === 'success') {
            alertClass = 'alert-success';
            iconClass = 'fa-check-circle';
            bgColor = '#E8F5E9';
            borderColor = '#4CAF50';
            titleColor = '#2E7D32';
        } else if (type === 'error') {
            alertClass = 'alert-danger';
            iconClass = 'fa-exclamation-circle';
            bgColor = '#FFEBEE';
            borderColor = '#F44336';
            titleColor = '#C62828';
        } else if (type === 'warning') {
            alertClass = 'alert-warning';
            iconClass = 'fa-exclamation-triangle';
            bgColor = '#FFF3E0';
            borderColor = '#FF9800';
            titleColor = '#E65100';
        }

        let modalHtml = `
            <div class="modal fade" id="alertModal" tabindex="-1" role="dialog" aria-hidden="true">
                <div class="modal-dialog" role="document">
                    <div class="modal-content" style="border-top: 4px solid ${borderColor};">
                        <div class="modal-header" style="background: ${bgColor}; border-bottom: 2px solid ${borderColor}; padding: 20px;">
                            <h5 class="modal-title" style="color: ${titleColor}; font-weight: 600;">
                                <i class="fa ${iconClass}"></i> ${title}
                            </h5>
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                        <div class="modal-body" style="padding: 20px; color: #333;">
                            ${message}
                        </div>
                        <div class="modal-footer" style="padding: 15px; border-top: 1px solid #E0E0E0;">
                            <button type="button" class="btn btn-primary" data-dismiss="modal" style="background-color: ${borderColor}; border: none;">
                                <i class="fa fa-check"></i> OK
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        `;

        // Remove existing alert modal if any
        $('#alertModal').remove();

        // Add new modal to body
        $('body').append(modalHtml);

        // Show modal
        $('#alertModal').modal('show');

        // Remove modal when hidden
        $('#alertModal').on('hidden.bs.modal', function() {
            $(this).remove();
        });
    }

    $(document).ready(function() {
        // LOAD SETTLEMENT RECORDS when tab is clicked
        $('a[href="#settlement-records-tab"]').on('click', function() {
            loadSettlementRecords();
        });

        // Function to load settlement records via AJAX
        function loadSettlementRecords() {
            $.ajax({
                url: 'get_settlement_records.php',
                method: 'GET',
                dataType: 'json',
                success: function(response) {
                    if (response.success) {
                        let records = response.data;
                        let tbody = $('#settlement-records-body');
                        let badgeEl = $('#settlement-count-badge');
                        
                        tbody.html('');
                        
                        if (records.length === 0) {
                            tbody.append(`
                                <tr>
                                    <td colspan="10" style="text-align: center; padding: 40px; color: #999;">
                                        <i class="fa fa-inbox" style="font-size: 24px; margin-bottom: 10px;"></i><br>
                                        No settlement records found
                                    </td>
                                </tr>
                            `);
                            badgeEl.text('0 records');
                        } else {
                            records.forEach(function(record) {
                                let statusClass = record.status === 'settled' ? 'success' : 'warning';
                                let adjustmentDisplay = record.adjustment_amount > 0 ? 
                                    (record.adjustment_reason && ['exclusion', 'discount', 'waived'].includes(record.adjustment_reason) ? 
                                        '-₱' + parseFloat(record.adjustment_amount).toFixed(2) : 
                                        '+₱' + parseFloat(record.adjustment_amount).toFixed(2)) : 
                                    '₱0.00';
                                
                                // Format date - handle both settlement_date and settled_at fields
                                let dateField = record.settlement_date || record.settled_at;
                                let formattedDate = dateField ? new Date(dateField).toLocaleDateString() : 'Invalid Date';
                                
                                let row = `
                                    <tr>
                                        <td><span style="background: #E3F2FD; color: #1565C0; padding: 4px 8px; border-radius: 3px; font-size: 11px; font-weight: 600;">${formattedDate}</span></td>
                                        <td>${htmlEscape(record.borrower_name)}</td>
                                        <td>${htmlEscape(record.book_title)}</td>
                                        <td><span style="background: #FFF3E0; color: #E65100; padding: 4px 8px; border-radius: 3px; font-weight: 600;">${record.days_overdue} days</span></td>
                                        <td>₱${parseFloat(record.calculated_fine || 0).toFixed(2)}</td>
                                        <td><strong>₱${parseFloat(record.calculated_fine).toFixed(2)}</strong></td>
                                        <td>${adjustmentDisplay}</td>
                                        <td><strong style="color: #1565C0; font-size: 14px;">₱${parseFloat(record.total_payable).toFixed(2)}</strong></td>
                                        <td><span class="label label-${statusClass}">${record.status.toUpperCase()}</span></td>
                                        <td><button class="btn btn-xs btn-info" onclick="viewSettlementDetails(${record.id})" title="View Details"><i class="fa fa-eye"></i></button></td>
                                    </tr>
                                `;
                                tbody.append(row);
                            });
                            badgeEl.text(records.length + ' record' + (records.length > 1 ? 's' : ''));
                            // Initialize pagination for settlement records
                            initializeSettlementPagination(records.length);
                        }
                    } else {
                        showAlertModal('error', 'Error Loading Records', response.message || 'Failed to load settlement records.');
                    }
                },
                error: function() {
                    showAlertModal('error', 'Connection Error', 'Unable to load settlement records. Please try again.');
                }
            });
        }

        // Helper function to escape HTML
        function htmlEscape(text) {
            return text.replace(/[&<>"']/g, function(char) {
                return {
                    '&': '&amp;',
                    '<': '&lt;',
                    '>': '&gt;',
                    '"': '&quot;',
                    "'": '&#039;'
                }[char];
            });
        }

        // Load fine amount from localStorage
        const savedFineAmount = localStorage.getItem('overdue_fine_amount');
        if (savedFineAmount) {
            $('#fineAmount').val(parseFloat(savedFineAmount).toFixed(2));
        }

        // Save fine amount
        $('#saveFineBtn').click(function() {
            const fineAmount = parseFloat($('#fineAmount').val());
            
            if (isNaN(fineAmount) || fineAmount < 0) {
                showAlertModal('warning', 'Invalid Input', 'Please enter a valid fine amount.');
                return;
            }

            localStorage.setItem('overdue_fine_amount', fineAmount.toFixed(2));
            
            // Show success message
            const btn = $(this);
            const originalHTML = btn.html();
            btn.html('<i class="fa fa-check"></i>').css('background-color', '#4CAF50');
            
            showAlertModal('success', 'Saved Successfully', 'Fine amount has been updated to ₱' + fineAmount.toFixed(2));
            
            setTimeout(function() {
                btn.html(originalHTML).css('background-color', '');
            }, 1500);
        });

        // Allow Enter key to save
        $('#fineAmount').keypress(function(e) {
            if (e.which == 13) {
                $('#saveFineBtn').click();
            }
        });

        // RETURN/SETTLE BUTTON CLICK
        $(document).on('click', 'button[title="Mark as Returned"]', function() {
            let transactionId = $(this).closest('tr').data('id');
            let row = $(this).closest('tr');
            let borrowerName = row.find('td:eq(1)').text().trim();
            let bookTitle = row.find('td:eq(3)').text().trim();
            let daysOverdue = row.find('td:eq(0)').text().trim();
            let dueDate = row.find('td:eq(5)').text().trim();

            // Get fine amount from localStorage
            const fineAmount = parseFloat(localStorage.getItem('overdue_fine_amount')) || 10;
            const daysNum = parseInt(daysOverdue.split(' ')[0]) || 0;

            // Fill modal with data
            $('#settle_transaction_id').val(transactionId);
            $('#settle_borrower_name').text(borrowerName);
            $('#settle_book_title').text(bookTitle);
            $('#settle_days_overdue').text(daysNum + ' days');
            $('#settle_due_date').text(dueDate);
            $('#settle_fine_per_day').val(fineAmount.toFixed(2));
            $('#settle_chargeable_days').val(daysNum);
            $('#settle_return_date').val(new Date().toISOString().split('T')[0]);

            // Calculate initial fine
            calculateSettleFine();

            $('#settleModal').modal('show');
        });

        // Calculate fine whenever inputs change
        $(document).on('input', '#settle_fine_per_day, #settle_chargeable_days, #settle_adjustment', function() {
            calculateSettleFine();
        });

        // Update adjustment symbol and label when reason changes
        $(document).on('change', '#settle_adjustment_reason', function() {
            let reason = $(this).val();
            let symbolEl = $('#settle_adjustment_symbol');
            let labelEl = $('#settle_adj_label');
            
            // Reasons that are MINUS (discounts/reductions)
            let minusReasons = ['exclusion', 'waived', 'discount'];
            // Reasons that are PLUS (additional charges)
            let plusReasons = ['lost_book', 'partial_return'];
            
            if (minusReasons.includes(reason)) {
                symbolEl.text('Deduct: ₱');
                labelEl.text('Less: Adjustment');
            } else if (plusReasons.includes(reason)) {
                symbolEl.text('Add: ₱');
                labelEl.text('Plus: Adjustment');
            } else {
                symbolEl.text('Adjustment: ₱');
                labelEl.text('Adjustment:');
            }
            
            calculateSettleFine();
        });

        // Function to calculate fine
        function calculateSettleFine() {
            let finePerDay = parseFloat($('#settle_fine_per_day').val()) || 0;
            let chargeableDays = parseInt($('#settle_chargeable_days').val()) || 0;
            let adjustment = parseFloat($('#settle_adjustment').val()) || 0;
            let reason = $('#settle_adjustment_reason').val();

            let calculatedFine = finePerDay * chargeableDays;
            
            // Determine if adjustment is minus (discount) or plus (additional charge)
            let minusReasons = ['exclusion', 'waived', 'discount'];
            let plusReasons = ['lost_book', 'partial_return'];
            let isMinus = minusReasons.includes(reason);
            let isPlus = plusReasons.includes(reason);
            
            let adjAmount = isMinus ? -adjustment : (isPlus ? adjustment : 0);
            let totalPayable = Math.max(0, calculatedFine + adjAmount);

            // Update displays
            $('#settle_calculated_fine').text('₱' + calculatedFine.toFixed(2));
            $('#settle_calc_display').text('₱' + calculatedFine.toFixed(2));
            
            if (isMinus) {
                $('#settle_adj_display').text('-₱' + adjustment.toFixed(2));
            } else if (isPlus) {
                $('#settle_adj_display').text('+₱' + adjustment.toFixed(2));
            } else {
                $('#settle_adj_display').text('₱0.00');
            }
            
            $('#settle_total_payable').text('₱' + totalPayable.toFixed(2));
        }

        // SUBMIT SETTLE/RETURN FORM
        $('#settleForm').submit(function(e) {
            e.preventDefault();
            
            // Validate adjustment reason if adjustment amount exists
            let adjustmentAmount = parseFloat($('#settle_adjustment').val()) || 0;
            let adjustmentReason = $('#settle_adjustment_reason').val();

            if (adjustmentAmount > 0 && !adjustmentReason) {
                showAlertModal('warning', 'Missing Information', 'Please select a reason for the adjustment.');
                return;
            }

            let transactionId = $('#settle_transaction_id').val();
            let returnDate = $('#settle_return_date').val();
            let settleStatus = $('#settle_status').val();

            // Map status to condition values expected by transaction_return.php
            let conditionMap = {
                'returned': 'good',
                'damaged': 'damaged',
                'lost': 'repair'  // treat lost as repair status
            };

            let condition = conditionMap[settleStatus] || 'good';

            // Gather all settlement data
            let finePerDay = parseFloat($('#settle_fine_per_day').val()) || 0;
            let chargeableDays = parseInt($('#settle_chargeable_days').val()) || 0;
            let calculatedFine = finePerDay * chargeableDays;
            
            // Determine if adjustment is minus (discount) or plus (additional charge)
            let minusReasons = ['exclusion', 'waived', 'discount'];
            let plusReasons = ['lost_book', 'partial_return'];
            let isMinus = minusReasons.includes(adjustmentReason);
            let isPlus = plusReasons.includes(adjustmentReason);
            
            let adjAmount = isMinus ? -adjustmentAmount : (isPlus ? adjustmentAmount : 0);
            let totalPayable = Math.max(0, calculatedFine + adjAmount);
            let adjustmentDetails = $('#settle_adjustment_details').val();

            $.ajax({
                url: 'transaction_return.php',
                type: 'POST',
                data: {
                    id: transactionId,
                    condition: condition,
                    finePerDay: finePerDay.toFixed(2),
                    chargeableDays: chargeableDays,
                    calculatedFine: calculatedFine.toFixed(2),
                    adjustmentAmount: adjustmentAmount.toFixed(2),
                    adjustmentReason: adjustmentReason,
                    adjustmentDetails: adjustmentDetails,
                    totalPayable: totalPayable.toFixed(2),
                    returnDate: returnDate
                },
                dataType: 'json',
                success: function(resp) {
                    if (resp.success === true) {
                        $('#settleModal').modal('hide');

                        // Find and remove the row from overdue table
                        let row = $('tr[data-id="' + transactionId + '"]');

                        if (row.length) {
                            row.fadeOut(300, function() {
                                $(this).remove();
                                // Update the overdue count badge
                                let badgeEl = $('.overdue-badge');
                                if (badgeEl.length) {
                                    let currentCount = parseInt(badgeEl.text());
                                    if (currentCount > 1) {
                                        badgeEl.text((currentCount - 1) + ' items');
                                    } else {
                                        // If only 1 item, reload page to show empty state
                                        location.reload();
                                    }
                                }
                            });
                        }

                        // Build success message with fine details
                        let successMsg = '✓ Book settled successfully!<br>';
                        successMsg += 'Fine: ₱' + calculatedFine.toFixed(2);
                        if (adjustmentAmount > 0) {
                            successMsg += '<br>Adjustment: -₱' + adjustmentAmount.toFixed(2);
                            successMsg += '<br>Total Payable: ₱' + totalPayable.toFixed(2);
                        }

                        // Show success message with modal
                        showAlertModal('success', 'Book Settled', successMsg);
                        
                        // Refresh the page after a short delay
                        setTimeout(function() {
                            location.reload();
                        }, 2000);
                    } else {
                        showAlertModal('error', 'Settlement Failed', 'Error: ' + (resp.message || 'Failed to settle book'));
                    }
                },
                error: function(xhr) {
                    showAlertModal('error', 'Server Error', 'An error occurred while processing your request. Please try again.');
                    console.error(xhr.responseText);
                }
            });
        });

        // ==================== OVERDUE NOTIFICATIONS ====================
        
        function sendOverdueNotifications() {
            let btn = $('#sendOverdueNotificationsBtn');
            let msgDiv = $('#overdueNotificationMessage');
            btn.prop('disabled', true);
            btn.html('<i class="fa fa-spinner fa-spin"></i> Sending...');
            
            $.ajax({
                url: 'send_overdue_notifications.php',
                type: 'POST',
                dataType: 'json',
                timeout: 30000,
                success: function(data) {
                    btn.prop('disabled', false);
                    btn.html('<i class="fa fa-paper-plane-o"></i> Send Now');
                    
                    if (data.success) {
                        // Build message
                        let msg = '<strong style="color: #4CAF50;">✓ ' + data.sent + ' sent</strong>';
                        if (data.failed > 0) {
                            msg += ' | <strong style="color: #2196F3;">⚠ ' + data.failed + ' skipped</strong>';
                        }
                        
                        // Show in widget
                        msgDiv.html(msg);
                        msgDiv.css({
                            'background': data.failed === 0 && data.sent > 0 ? '#C8E6C9' : '#E3F2FD',
                            'color': data.failed === 0 && data.sent > 0 ? '#2E7D32' : '#1565C0',
                            'border-left': '3px solid ' + (data.failed === 0 && data.sent > 0 ? '#4CAF50' : '#2196F3')
                        });
                        msgDiv.show();
                        
                        // Show modal
                        let modalMsg = '<div style="text-align: left;">';
                        modalMsg += '<p><strong style="color: #4CAF50;">✓ Sent: ' + data.sent + ' email(s)</strong></p>';
                        if (data.failed > 0) {
                            modalMsg += '<p style="color: #FF9800;"><strong>⚠ Skipped: ' + data.failed + ' (already notified today)</strong></p>';
                        }
                        if (data.sent === 0 && data.failed > 0) {
                            modalMsg += '<p style="color: #666; font-size: 12px; margin-top: 10px;"><em>All overdue books have been notified within the last 24 hours.</em></p>';
                        }
                        modalMsg += '</div>';
                        
                        showAlertModal(data.failed === 0 ? 'success' : 'info', 'Overdue Notifications', modalMsg);
                    } else {
                        msgDiv.html('<strong style="color: #FF9800;">' + data.message + '</strong>');
                        msgDiv.css('background', '#FFE0B2').css('color', '#E65100').css('border-left', '3px solid #FF9800');
                        msgDiv.show();
                    }
                },
                error: function(xhr, status, error) {
                    btn.prop('disabled', false);
                    btn.html('<i class="fa fa-paper-plane-o"></i> Send Now');
                    msgDiv.html('<strong style="color: #E53935;">Connection Error</strong>');
                    msgDiv.css('background', '#FFCDD2').css('color', '#C62828').css('border-left', '3px solid #E53935');
                    msgDiv.show();
                    console.error(error);
                }
            });
        }
        
        // Attach click handler
        $('#sendOverdueNotificationsBtn').on('click', function() {
            sendOverdueNotifications();
        });

        // ==================== DUE DATE NOTIFICATIONS ====================
        // Auto-send notifications for due date (same as overdue)
        // These are sent automatically at page load via overdue_notifier.php

        // ==================== PAGINATION LOGIC ====================
        
        // Pagination for Overdue Books Table
        let overdueCurrentPage = 1;
        let overdueRowsPerPage = 10;
        let overdueAllRows = [];
        
        function initializeOverduePagination() {
            overdueAllRows = $('tbody tr', '#overdue-table');
            let totalRows = overdueAllRows.length;
            let totalPages = Math.ceil(totalRows / overdueRowsPerPage);
            
            renderOverduePagination(totalPages);
            showOverdueRows(1);
        }
        
        function renderOverduePagination(totalPages) {
            let pagination = $('#overdue-pagination');
            pagination.html('');
            
            // Previous button
            pagination.append(`<li class="${overdueCurrentPage === 1 ? 'disabled' : ''}"><a href="#" onclick="changeOverduePagePage(${overdueCurrentPage - 1}); return false;">&laquo;</a></li>`);
            
            // Page numbers
            for (let i = 1; i <= totalPages; i++) {
                if (i === overdueCurrentPage) {
                    pagination.append(`<li class="active"><a href="#">${i}</a></li>`);
                } else {
                    pagination.append(`<li><a href="#" onclick="changeOverduePagePage(${i}); return false;">${i}</a></li>`);
                }
            }
            
            // Next button
            pagination.append(`<li class="${overdueCurrentPage === totalPages ? 'disabled' : ''}"><a href="#" onclick="changeOverduePagePage(${overdueCurrentPage + 1}); return false;">&raquo;</a></li>`);
        }
        
        function changeOverduePagePage(page) {
            let totalPages = Math.ceil(overdueAllRows.length / overdueRowsPerPage);
            if (page < 1 || page > totalPages) return;
            
            overdueCurrentPage = page;
            showOverdueRows(page);
            renderOverduePagination(totalPages);
        }
        
        function showOverdueRows(page) {
            overdueAllRows.hide();
            let start = (page - 1) * overdueRowsPerPage;
            let end = start + overdueRowsPerPage;
            
            overdueAllRows.slice(start, end).show();
            
            // Update pagination info
            $('#overdue-start').text(overdueAllRows.length > 0 ? start + 1 : 0);
            $('#overdue-end').text(Math.min(end, overdueAllRows.length));
        }

        // Pagination for Settlement Records Table
        let settlementCurrentPage = 1;
        let settlementRowsPerPage = 10;
        let settlementAllRows = [];
        let settlementTotalRecords = 0;
        
        function initializeSettlementPagination(totalRecords) {
            settlementTotalRecords = totalRecords;
            settlementAllRows = $('tbody tr', '#settlement-records-table');
            let totalPages = Math.ceil(totalRecords / settlementRowsPerPage);
            
            renderSettlementPagination(totalPages);
            showSettlementRows(1);
        }
        
        function renderSettlementPagination(totalPages) {
            let pagination = $('#settlement-pagination');
            pagination.html('');
            
            if (totalPages <= 1) return;
            
            // Previous button
            pagination.append(`<li class="${settlementCurrentPage === 1 ? 'disabled' : ''}"><a href="#" onclick="changeSettlementPage(${settlementCurrentPage - 1}); return false;">&laquo;</a></li>`);
            
            // Page numbers
            for (let i = 1; i <= totalPages; i++) {
                if (i === settlementCurrentPage) {
                    pagination.append(`<li class="active"><a href="#">${i}</a></li>`);
                } else {
                    pagination.append(`<li><a href="#" onclick="changeSettlementPage(${i}); return false;">${i}</a></li>`);
                }
            }
            
            // Next button
            pagination.append(`<li class="${settlementCurrentPage === totalPages ? 'disabled' : ''}"><a href="#" onclick="changeSettlementPage(${settlementCurrentPage + 1}); return false;">&raquo;</a></li>`);
        }
        
        function changeSettlementPage(page) {
            let totalPages = Math.ceil(settlementTotalRecords / settlementRowsPerPage);
            if (page < 1 || page > totalPages) return;
            
            settlementCurrentPage = page;
            showSettlementRows(page);
            renderSettlementPagination(totalPages);
        }
        
        function showSettlementRows(page) {
            settlementAllRows.hide();
            let start = (page - 1) * settlementRowsPerPage;
            let end = start + settlementRowsPerPage;
            
            settlementAllRows.slice(start, end).show();
            
            // Update pagination info
            $('#settlement-start').text(settlementTotalRecords > 0 ? start + 1 : 0);
            $('#settlement-end').text(Math.min(end, settlementTotalRecords));
        }
        
        // Initialize overdue pagination on page load
        $(document).ready(function() {
            initializeOverduePagination();
            
            // Check if settle parameter exists - if so, open settlement modal for that transaction
            const urlParams = new URLSearchParams(window.location.search);
            const settleId = urlParams.get('settle');
            
            if (settleId) {
                // Load transaction data and open settlement modal
                $.ajax({
                    url: 'transaction_get_view.php',
                    type: 'POST',
                    data: { id: settleId },
                    dataType: 'json',
                    success: function(resp) {
                        if (resp.status === 'success') {
                            let t = resp.data;
                            
                            // Pre-fill settlement modal
                            $('#settle_transaction_id').val(t.id);
                            $('#settle_borrower_name').text(t.borrower_name || 'Unknown');
                            $('#settle_book_title').text(t.book_title || 'Unknown');
                            $('#settle_due_date').text(t.due_date || '');
                            
                            // Calculate days overdue
                            let dueDate = new Date(t.due_date);
                            let today = new Date();
                            let daysOverdue = Math.floor((today - dueDate) / (1000 * 60 * 60 * 24));
                            $('#settle_days_overdue').text(daysOverdue + ' days');
                            
                            // Set return date to today
                            $('#settle_return_date').val(new Date().toISOString().split('T')[0]);
                            
                            // Open the settlement modal
                            $('#settleModal').modal('show');
                        }
                    },
                    error: function() {
                        console.log('Error loading transaction data for settlement');
                    }
                });
            }
        });
    });
    </script>
</div>

</body>
</html>